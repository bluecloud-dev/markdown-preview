# How to Use SpecKit

**Version**: 1.0.0
**Last Updated**: 2025-12-26

SpecKit is a specification-driven development workflow that uses Claude AI to generate design artifacts and implement features systematically.

> **Note**: All diagrams in this documentation use Mermaid for consistency and portability.

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Command Overview](#command-overview)
3. [Model Strategy](#model-strategy)
4. [Complete Workflow](#complete-workflow)
5. [Git Branch Flow](#git-branch-flow)
6. [Command Reference](#command-reference)
7. [Best Practices](#best-practices)
8. [Troubleshooting](#troubleshooting)

---

## Quick Start

```bash
# 1. Start a new feature (creates spec branch)
/speckit.specify my-awesome-feature

# 2. Generate implementation artifacts
/speckit.plan
/speckit.tasks

# 3. Create GitHub infrastructure
/speckit.issues

# 4. Implement tasks one by one
/speckit.implement T001
/speckit.implement T002
# ... continue for all tasks

# 5. Release the milestone
/speckit.milestone 0.1.0
```

---

## Command Overview

### Complete SpecKit Flow

```mermaid
%%{init: {'theme': 'base', 'themeVariables': {'primaryColor': '#4A90A4', 'primaryTextColor': '#fff', 'primaryBorderColor': '#2C5F6E', 'lineColor': '#5C6BC0', 'secondaryColor': '#81C784', 'tertiaryColor': '#FFB74D'}}}%%
flowchart TB
    subgraph THINKING["🧠 THINKING PHASE (Opus 4.5)"]
        direction TB
        specify["<b>/speckit.specify</b><br/>Creates spec branch<br/>+ spec.md"]
        clarify["<b>/speckit.clarify</b><br/>(optional)<br/>5 targeted questions"]
        plan["<b>/speckit.plan</b><br/>Creates plan.md"]
        tasks["<b>/speckit.tasks</b><br/>Creates tasks.md"]
        roadmap["<b>/speckit.roadmap</b><br/>docs/ROADMAP.md<br/>+ diagrams"]
        analyze["<b>/speckit.analyze</b><br/>Cross-check:<br/>gaps, conflicts"]

        specify --> clarify
        clarify --> plan
        plan --> tasks
        tasks --> roadmap
        specify --> analyze
        tasks --> analyze
        roadmap --> analyze
    end

    subgraph EXECUTION["⚡ EXECUTION PHASE (Sonnet 4.5)"]
        direction TB
        issues["<b>/speckit.issues</b><br/>Labels, Milestones<br/>Epic + Task Issues"]
        implement["<b>/speckit.implement</b><br/>Task branch → TDD<br/>→ PR to spec"]
        milestone["<b>/speckit.milestone</b><br/>PR to main<br/>Tag + Release"]

        issues --> implement
        implement -->|"repeat for<br/>all tasks"| implement
        implement --> milestone
    end

    THINKING --> EXECUTION

    style THINKING fill:#E3F2FD,stroke:#1565C0,stroke-width:2px
    style EXECUTION fill:#E8F5E9,stroke:#2E7D32,stroke-width:2px
    style specify fill:#4A90A4,color:#fff
    style plan fill:#4A90A4,color:#fff
    style tasks fill:#4A90A4,color:#fff
    style roadmap fill:#4A90A4,color:#fff
    style analyze fill:#4A90A4,color:#fff
    style clarify fill:#78909C,color:#fff
    style issues fill:#81C784,color:#000
    style implement fill:#81C784,color:#000
    style milestone fill:#FFB74D,color:#000
```

### Thinking vs Execution Commands

```mermaid
%%{init: {'theme': 'base'}}%%
graph LR
    subgraph OPUS["Claude Opus 4.5"]
        O1["/speckit.specify"]
        O2["/speckit.clarify"]
        O3["/speckit.plan"]
        O4["/speckit.tasks"]
        O5["/speckit.roadmap"]
        O6["/speckit.analyze"]
    end

    subgraph SONNET["Claude Sonnet 4.5"]
        S1["/speckit.issues"]
        S2["/speckit.implement"]
        S3["/speckit.milestone"]
    end

    OPUS -->|"Deep reasoning<br/>Architecture<br/>Synthesis"| SONNET
    SONNET -->|"Fast iteration<br/>API calls<br/>TDD cycles"| DONE((Done))

    style OPUS fill:#E3F2FD,stroke:#1565C0
    style SONNET fill:#E8F5E9,stroke:#2E7D32
    style DONE fill:#FFB74D,stroke:#F57C00
```

---

## Model Strategy

SpecKit uses different Claude models optimized for different task types:

### Thinking Commands → Claude Opus 4.5

Best for tasks requiring deep reasoning, architecture decisions, and multi-artifact synthesis.

| Command | Purpose | Why Opus |
|---------|---------|----------|
| `/speckit.specify` | Create feature specification | Requirements analysis, edge case discovery |
| `/speckit.clarify` | Identify underspecified areas | Ambiguity detection, targeted questions |
| `/speckit.plan` | Generate implementation plan | Architecture decisions, trade-off analysis |
| `/speckit.tasks` | Break down into tasks | Dependency ordering, parallel detection |
| `/speckit.roadmap` | Create roadmap documentation | Strategic synthesis, visualization |
| `/speckit.analyze` | Cross-artifact consistency | Gap detection, constitution alignment |

**Opus Optimizations Applied:**
- Extended thinking triggers ("think hard")
- High-level instructions (not step-by-step)
- Self-verification checklists
- Constraint-based prompting

### Execution Commands → Claude Sonnet 4.5

Best for fast iteration, routine operations, and explicit step-by-step workflows.

| Command | Purpose | Why Sonnet |
|---------|---------|------------|
| `/speckit.issues` | Create GitHub infrastructure | Bulk API calls, template application |
| `/speckit.implement` | Execute TDD implementation | Fast iteration, single-file changes |
| `/speckit.milestone` | Complete release workflow | Sequential Git operations |

**Sonnet Optimizations Applied:**
- Explicit step-by-step instructions
- Validation checkpoints after each step
- Error recovery tables
- "STOP and report" on failure

---

## Complete Workflow

### Workflow Phases

```mermaid
%%{init: {'theme': 'base'}}%%
timeline
    title SpecKit Development Lifecycle

    section Specification
        /speckit.specify : Create spec branch
                        : Generate spec.md
        /speckit.clarify : Ask clarifying questions
                        : Update spec.md
        /speckit.plan : Generate plan.md
                     : Architecture decisions
        /speckit.tasks : Generate tasks.md
                      : Dependency ordering

    section Validation
        /speckit.roadmap : docs/ROADMAP.md
                        : Mermaid diagrams
        /speckit.analyze : Cross-check artifacts
                        : Detect gaps

    section GitHub Setup
        /speckit.issues : Create labels
                       : Create milestones
                       : Create issues

    section Implementation
        /speckit.implement : Task branches
                          : TDD cycles
                          : PRs to spec

    section Release
        /speckit.milestone : Version bump
                          : Release PR
                          : Tag + Release
```

### Phase 1: Specification (Thinking)

```bash
# Step 1: Create specification
# Creates: spec/{feature} branch, specs/{feature}/spec.md
/speckit.specify markdown-preview

# Step 2: (Optional) Clarify ambiguities
# Asks 5 targeted questions, updates spec.md
/speckit.clarify

# Step 3: Generate implementation plan
# Creates: specs/{feature}/plan.md
/speckit.plan

# Step 4: Generate task breakdown
# Creates: specs/{feature}/tasks.md
/speckit.tasks

# Step 5: (Optional) Generate roadmap
# Creates: docs/ROADMAP.md (includes diagrams)
/speckit.roadmap

# Step 6: Verify consistency
# Checks for gaps, conflicts, missing coverage
/speckit.analyze
```

### Phase 2: GitHub Setup (Execution)

```bash
# Create GitHub infrastructure
# Creates: labels, milestones, issues
/speckit.issues
```

**What Gets Created:**

| Resource | Count | Examples |
|----------|-------|----------|
| Labels | ~20 | `type:feat`, `priority:P0`, `status:in-progress` |
| Milestones | 5 | v0.1.0, v0.2.0, v0.3.0, v0.4.0, v1.0.0 |
| Epic Issues | 6 | One per user story |
| Task Issues | 133+ | One per task in tasks.md |

### Phase 3: Implementation (Execution)

```bash
# Implement a single task
/speckit.implement T001

# Implement a range of tasks
/speckit.implement T001-T011

# Implement an entire phase
/speckit.implement --phase 1

# Resume interrupted session
/speckit.implement --continue
```

### Implementation Flow Per Task

```mermaid
%%{init: {'theme': 'base'}}%%
flowchart TD
    A[Start Task] --> B{On spec branch?}
    B -->|No| C[Checkout spec branch]
    B -->|Yes| D[Pull latest]
    C --> D
    D --> E[Create task branch]
    E --> F[Write failing test]
    F --> G[Implement code]
    G --> H{Tests pass?}
    H -->|No| G
    H -->|Yes| I[Commit changes]
    I --> J[Push branch]
    J --> K[Create PR]
    K --> L{More tasks?}
    L -->|Yes| D
    L -->|No| M[Done]

    style A fill:#4A90A4,color:#fff
    style F fill:#ff6b6b,color:#fff
    style H fill:#FFB74D,color:#000
    style M fill:#81C784,color:#000
```

### Phase 4: Release (Execution)

```bash
# Complete milestone and release
/speckit.milestone 0.1.0
```

### Milestone Completion Flow

```mermaid
%%{init: {'theme': 'base'}}%%
flowchart LR
    A[Verify Issues<br/>Closed] --> B[Update<br/>package.json]
    B --> C[Update<br/>CHANGELOG]
    C --> D[Create PR<br/>to main]
    D --> E[Merge PR]
    E --> F[Create Tag]
    F --> G[GitHub<br/>Release]
    G --> H[Close<br/>Milestone]

    style A fill:#4A90A4,color:#fff
    style D fill:#FFB74D,color:#000
    style F fill:#81C784,color:#000
    style G fill:#81C784,color:#000
    style H fill:#81C784,color:#000
```

---

## Git Branch Flow

### Branch Hierarchy

```mermaid
%%{init: {'theme': 'base'}}%%
gitGraph
    commit id: "main"
    branch spec/feature
    checkout spec/feature
    commit id: "spec.md" tag: "specify"
    commit id: "plan.md" tag: "plan"
    commit id: "tasks.md" tag: "tasks"
    branch task/feature/T001
    checkout task/feature/T001
    commit id: "T001 impl"
    checkout spec/feature
    merge task/feature/T001 id: "PR #1"
    branch task/feature/T002
    checkout task/feature/T002
    commit id: "T002 impl"
    checkout spec/feature
    merge task/feature/T002 id: "PR #2"
    commit id: "..."
    commit id: "All tasks"
    checkout main
    merge spec/feature id: "Release" tag: "v0.1.0" type: HIGHLIGHT
```

### Branch Structure Diagram

```mermaid
%%{init: {'theme': 'base'}}%%
flowchart TB
    subgraph MAIN["main (protected)"]
        M[main branch]
    end

    subgraph SPEC["spec/{feature}"]
        S[spec branch]
        S1[specs/{feature}/spec.md]
        S2[specs/{feature}/plan.md]
        S3[specs/{feature}/tasks.md]
        S4[docs/ROADMAP.md]
    end

    subgraph TASKS["task/{feature}/T###"]
        T1[task/T001-...]
        T2[task/T002-...]
        T3[task/T003-...]
    end

    M -->|"/speckit.specify"| S
    S --> S1
    S --> S2
    S --> S3
    S --> S4
    S -->|"/speckit.implement"| T1
    S -->|"/speckit.implement"| T2
    S -->|"/speckit.implement"| T3
    T1 -->|"PR"| S
    T2 -->|"PR"| S
    T3 -->|"PR"| S
    S -->|"/speckit.milestone"| M

    style MAIN fill:#90EE90,stroke:#2E7D32
    style SPEC fill:#4A90A4,stroke:#2C5F6E
    style TASKS fill:#FFB74D,stroke:#F57C00
```

### Branch Naming Conventions

| Branch Type | Pattern | Example |
|-------------|---------|---------|
| Main | `main` | `main` |
| Spec | `spec/{feature-kebab-case}` | `spec/markdown-preview` |
| Task | `task/{feature}/T{id}-{slug}` | `task/markdown-preview/T001-test-scaffolding` |

---

## Command Reference

### `/speckit.specify`

Create a new feature specification.

```bash
/speckit.specify {feature-name}
```

**Input:** Feature description (natural language)
**Output:**
- Creates `spec/{feature}` branch
- Creates `specs/{feature}/spec.md`

**Example:**
```bash
/speckit.specify markdown-preview
```

---

### `/speckit.clarify`

Identify underspecified areas and ask targeted questions.

```bash
/speckit.clarify
```

**Input:** Existing `spec.md`
**Output:** Up to 5 clarification questions, updated `spec.md`

---

### `/speckit.plan`

Generate implementation plan from specification.

```bash
/speckit.plan
```

**Input:** `spec.md`
**Output:** `plan.md` with architecture, dependencies, project structure

---

### `/speckit.tasks`

Generate task breakdown with dependencies.

```bash
/speckit.tasks
```

**Input:** `spec.md`, `plan.md`
**Output:** `tasks.md` with milestone steps, parallel markers, user story mappings

---

### `/speckit.roadmap`

Generate roadmap documentation with visualizations.

```bash
/speckit.roadmap
```

**Input:** `spec.md`, `plan.md`, `tasks.md`
**Output:**
- `docs/ROADMAP.md` - Executive overview with Mermaid visualizations

---

### `/speckit.analyze`

Cross-artifact consistency check.

```bash
/speckit.analyze
```

**Input:** All spec artifacts + constitution
**Output:** Report with:
- Duplications
- Ambiguities
- Underspecifications
- Constitution violations
- Coverage gaps
- Inconsistencies

---

### `/speckit.issues`

Create GitHub infrastructure from tasks.

```bash
/speckit.issues
```

**Input:** `tasks.md`
**Output:** GitHub labels, milestones, epic issues, task issues

**Prerequisites:**
- `gh` CLI authenticated
- Repository on GitHub

---

### `/speckit.implement`

Execute task implementation with TDD.

```bash
# Single task
/speckit.implement T001

# Task range
/speckit.implement T001-T011

# Full phase
/speckit.implement --phase 1

# Resume
/speckit.implement --continue

# With auto-merge
/speckit.implement T001 --auto-merge
```

**Input:** Task ID(s) from `tasks.md`
**Output:** Task branch, implementation, PR to spec branch

---

### `/speckit.milestone`

Complete milestone with release.

```bash
/speckit.milestone 0.1.0
```

**Input:** Semantic version
**Output:**
- Updated `README.md` so Features/Commands list only what is available in the release (no milestone/version mentions)
- Version bump in `package.json`
- Updated `CHANGELOG.md`
- Release PR to `main`
- Git tag
- GitHub Release

**Prerequisites:**
- README.md updated for the release (no milestone/version mentions in Features/Commands)
- All milestone issues closed
- On spec branch
- Clean working directory

---

## Best Practices

### Workflow Best Practices

```mermaid
%%{init: {'theme': 'base'}}%%
flowchart LR
    subgraph GOOD["✅ Recommended"]
        G1[specify] --> G2[plan] --> G3[tasks] --> G4[analyze] --> G5[issues]
    end

    subgraph BAD["❌ Avoid"]
        B1[specify] --> B2[issues]
    end

    style GOOD fill:#E8F5E9,stroke:#2E7D32
    style BAD fill:#FFEBEE,stroke:#C62828
```

### 1. Always Run Analyze Before Implementation

```bash
/speckit.specify my-feature
/speckit.plan
/speckit.tasks
/speckit.analyze  # ← Catch issues before coding
/speckit.issues
```

### 2. Use Clarify for Complex Features

```bash
/speckit.specify complex-feature
/speckit.clarify  # ← Reduces ambiguity early
/speckit.plan
```

### 3. Implement Tasks in Order

Tasks are dependency-ordered. Implement sequentially within each phase:

```bash
# Phase 1 first
/speckit.implement T001
/speckit.implement T002
# ...

# Then Phase 2
/speckit.implement T012
```

### 4. Review PRs Before Continuing

Don't batch too many unmerged PRs:

```bash
/speckit.implement T001
# Wait for PR review/merge
/speckit.implement T002
```

### 5. Keep Spec Branch Updated

Before starting new tasks:

```bash
git checkout spec/{feature}
git pull origin spec/{feature}
```

---

## Troubleshooting

### Decision Tree

```mermaid
%%{init: {'theme': 'base'}}%%
flowchart TD
    A[Error Occurred] --> B{What type?}

    B -->|"Task not found"| C[Check task ID format<br/>Use T001 not 001]
    B -->|"Not on spec branch"| D[git checkout spec/feature]
    B -->|"Issues still open"| E[Close issues first<br/>gh issue close #]
    B -->|"PR conflicts"| F[Rebase on spec branch]
    B -->|"Tests fail"| G[Fix code, re-run tests]

    C --> H[Retry command]
    D --> H
    E --> H
    F --> H
    G --> H

    style A fill:#ff6b6b,color:#fff
    style H fill:#81C784,color:#000
```

### "Task not found in tasks.md"

Ensure you're using the correct task ID format: `T001`, `T002`, etc.

```bash
# Correct
/speckit.implement T001

# Wrong
/speckit.implement 001
/speckit.implement Task001
```

### "Must be on spec branch"

Switch to the spec branch before running implement or milestone:

```bash
git checkout spec/{feature}
```

### "Issues still open in milestone"

All issues must be closed before releasing:

```bash
# Check open issues
gh issue list --milestone "v0.1.0" --state open

# Close an issue
gh issue close {number}
```

### "PR conflicts"

Rebase your task branch on the spec branch:

```bash
git checkout task/{feature}/T001-desc
git rebase spec/{feature}
git push --force-with-lease
```

### "Tests fail after implementation"

The TDD cycle requires tests to pass:

```bash
npm test -- --grep "T001"
npm run lint
```

Fix issues before committing.

---

## File Structure

### Project Layout After SpecKit

```mermaid
%%{init: {'theme': 'base'}}%%
flowchart TB
    subgraph PROJECT["project/"]
        subgraph SPECIFY[".specify/"]
            M["memory/<br/>constitution.md"]
            SK["skills/<br/>*.SKILL.md"]
            C["cache/<br/>workflow-state.json"]
            DOC["HOW-TO-USE-SPECKIT.md"]
        end

        subgraph SPECS["specs/{feature}/"]
            SP["spec.md"]
            PL["plan.md"]
            TA["tasks.md"]
            DM["data-model.md"]
            QS["quickstart.md"]
        end

        RM["docs/ROADMAP.md"]
        CL["CHANGELOG.md"]
    end

    style SPECIFY fill:#E3F2FD,stroke:#1565C0
    style SPECS fill:#E8F5E9,stroke:#2E7D32
```

**Directory Structure:**

```
project/
├── .specify/
│   ├── memory/
│   │   └── constitution.md          # Project principles
│   ├── skills/
│   │   ├── roadmap/SKILL.md
│   │   ├── issues/SKILL.md
│   │   ├── implement/SKILL.md
│   │   ├── milestone/SKILL.md
│   │   └── workflow/SKILL.md
│   ├── cache/
│   │   └── workflow-state.json      # Implementation progress
│   ├── CLAUDE-MODEL-OPTIMIZATION.md # Model strategy docs
│   └── HOW-TO-USE-SPECKIT.md        # This file
├── specs/
│   └── {feature}/
│       ├── spec.md                  # Feature specification
│       ├── plan.md                  # Implementation plan
│       ├── tasks.md                 # Task breakdown
│       ├── data-model.md            # Data structures
│       └── quickstart.md            # Test scenarios
├── docs/
│   └── ROADMAP.md                   # Project roadmap + diagrams
└── CHANGELOG.md                     # Release history
```

---

## Related Documentation

- [CLAUDE-MODEL-OPTIMIZATION.md](CLAUDE-MODEL-OPTIMIZATION.md) - Model selection research
- [constitution.md](memory/constitution.md) - Project principles
- [SKILL-PACK.md](skills/SKILL-PACK.md) - Portable skill definitions

---

**License**: MIT
