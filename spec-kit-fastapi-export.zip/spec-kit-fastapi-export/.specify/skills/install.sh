#!/bin/bash
# SpecKit Branching Workflow - Skill Pack Installer
# Usage: curl -sL <url>/install.sh | bash
#    or: ./.specify/skills/install.sh

set -e

SKILLS_DIR=".specify/skills"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}  SpecKit Branching Workflow - Skill Pack${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Check if we're in a git repo
if ! git rev-parse --git-dir > /dev/null 2>&1; then
    echo -e "${RED}Error: Not a git repository${NC}"
    exit 1
fi

# Create skills directory structure
echo -e "${GREEN}Creating skills directory structure...${NC}"
mkdir -p "$SKILLS_DIR"/{workflow,roadmap,issues,implement,milestone}

# If running from within the skills directory, copy existing files
if [ -f "$SCRIPT_DIR/workflow/SKILL.md" ]; then
    echo -e "${GREEN}Copying skills from source...${NC}"
    cp -r "$SCRIPT_DIR"/{workflow,roadmap,issues,implement,milestone} "$SKILLS_DIR/" 2>/dev/null || true
else
    # Create skills from embedded content
    echo -e "${GREEN}Creating skill definitions...${NC}"

    # Workflow Skill
    cat > "$SKILLS_DIR/workflow/SKILL.md" << 'EOF'
---
name: speckit.workflow
description: Defines the SpecKit branching strategy and Git workflow. Spec branches contain all design artifacts; task branches implement individual tasks with PRs back to spec branch; milestone completion triggers PR to main with tag and release.
---

# SpecKit Git Workflow

## Branch Hierarchy

```
main (protected)
├── spec/{feature-name}           # Specification branch
└── task/{feature}/{task-id}      # Task branches
```

## Branch Naming

| Type | Pattern | Example |
|------|---------|---------|
| Spec | `spec/{feature}` | `spec/user-auth` |
| Task | `task/{feature}/{id}-{desc}` | `task/user-auth/T001-setup` |

## Workflow

1. `/speckit.specify` → Creates spec branch
2. `/speckit.plan` → Adds plan.md
3. `/speckit.tasks` → Adds tasks.md
4. `/speckit.issues` → Creates GitHub issues
5. `/speckit.implement T001` → Task branch + PR
6. `/speckit.milestone 0.1.0` → Release PR + tag
EOF

    # Roadmap Skill
    cat > "$SKILLS_DIR/roadmap/SKILL.md" << 'EOF'
---
name: speckit.roadmap
description: Generate docs/ROADMAP.md from tasks.md with Mermaid visualizations.
---

# Roadmap Generation

## Inputs
- specs/{feature}/tasks.md
- specs/{feature}/plan.md
- specs/{feature}/spec.md

## Outputs
- docs/ROADMAP.md (executive summary, versions, metrics, diagrams)

## Version Mapping
| Step | Version |
|------|---------|
| Sprint 0 | Sprint 0 |
| Foundational + US1 + US2 | v0.1.0 (MVP) |
| US3 | v0.2.0 |
| US4 + US5 | v0.3.0 |
| US6 | v0.4.0 |
| Polish | v1.0.0 |
EOF

    # Issues Skill
    cat > "$SKILLS_DIR/issues/SKILL.md" << 'EOF'
---
name: speckit.issues
description: Create GitHub issues from tasks.md with milestones, labels, and project organization.
---

# GitHub Issues Generation

## Labels
- type: feat, fix, docs, test, chore
- priority: P0, P1, P2, P3
- special: epic, mvp, good first issue

## Milestones
- v0.1.0 (MVP), v0.2.0, v0.3.0, v0.4.0, v1.0.0

## Issue Title Format
`[T001] Task description`
EOF

    # Implement Skill
    cat > "$SKILLS_DIR/implement/SKILL.md" << 'EOF'
---
name: speckit.implement
description: Execute tasks with task branches and PRs to spec branch.
---

# Implementation Workflow

## Usage
- `/speckit.implement T001` - Single task
- `/speckit.implement T001-T011` - Range
- `/speckit.implement --phase 1` - Full phase

## Per Task
1. Create branch: `task/{feature}/T{id}-{slug}`
2. Write failing test (TDD)
3. Implement
4. Commit and push
5. Create PR to spec branch
6. Link GitHub issue

## PR Title Format
`[T001] Task description`
EOF

    # Milestone Skill
    cat > "$SKILLS_DIR/milestone/SKILL.md" << 'EOF'
---
name: speckit.milestone
description: Complete milestone with release PR, tag, and GitHub release.
---

# Milestone Completion

## Usage
`/speckit.milestone 0.1.0`

## Steps
1. Verify all issues closed
2. Update README.md for release (Features/Commands only; no milestone/version mentions)
3. Update version + CHANGELOG
4. Create PR to main
5. After merge: tag + release
6. Close milestone
EOF
fi

# Create SKILL-PACK.md index
cat > "$SKILLS_DIR/README.md" << 'EOF'
# SpecKit Skills

Branching workflow skills for specification-driven development.

## Available Skills

| Skill | Command | Purpose |
|-------|---------|---------|
| Workflow | `/speckit.workflow` | Branching strategy |
| Roadmap | `/speckit.roadmap` | Generate roadmap docs |
| Issues | `/speckit.issues` | Create GitHub issues |
| Implement | `/speckit.implement` | Task branches + PRs |
| Milestone | `/speckit.milestone` | Release workflow |

## Workflow

```
main
  └── spec/{feature}           ← specify, plan, tasks
        └── task/{feature}/T001 ← implement
              └── PR → spec branch
                    └── milestone → PR to main → tag → release
```
EOF

echo ""
echo -e "${GREEN}✅ SpecKit skills installed successfully!${NC}"
echo ""
echo -e "Skills installed to: ${BLUE}$SKILLS_DIR/${NC}"
echo ""
echo "Available commands:"
echo "  /speckit.workflow  - View branching strategy"
echo "  /speckit.roadmap   - Generate roadmap from tasks"
echo "  /speckit.issues    - Create GitHub issues"
echo "  /speckit.implement - Implement tasks with branches"
echo "  /speckit.milestone - Complete milestone release"
echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
