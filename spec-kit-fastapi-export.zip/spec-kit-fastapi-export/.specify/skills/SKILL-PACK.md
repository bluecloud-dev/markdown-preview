# SpecKit Skill Pack: Branching Workflow

Portable skill definitions for specification-driven development with Git branching workflow.

**Version**: 1.0.0
**Created**: 2025-12-26
**Skills Included**: 5

## Quick Install

```bash
# From project root, run:
curl -sL https://raw.githubusercontent.com/YOUR_USER/YOUR_REPO/main/.specify/skills/install.sh | bash

# Or manually copy the .specify/skills/ directory to your project
```

## Skills Overview

| Skill | Command | Purpose |
|-------|---------|---------|
| Workflow | `/speckit.workflow` | Branching strategy definition |
| Roadmap | `/speckit.roadmap` | Generate docs/ROADMAP.md with Mermaid diagrams |
| Issues | `/speckit.issues` | Create GitHub issues, milestones, labels |
| Implement | `/speckit.implement` | Task branches with PRs to spec branch |
| Milestone | `/speckit.milestone` | Release PR to main, tag, GitHub release |

## Workflow Diagram

```
main (protected)
  │
  └── spec/{feature}                    ← /speckit.specify creates this
        │   ├── spec.md                 ← /speckit.specify
        │   ├── plan.md                 ← /speckit.plan
        │   └── tasks.md                ← /speckit.tasks
        │
        └── docs/ROADMAP.md             ← /speckit.roadmap
        │
        ├── task/{feature}/T001-...     ← /speckit.implement T001
        │     └── PR → spec/{feature}
        │
        └── All tasks merged
              └── /speckit.milestone    → PR to main → Tag → Release
```

---

# Skill Definitions

Copy each section below into `.specify/skills/{skill-name}/SKILL.md`

---

## 1. Workflow Skill

**File**: `.specify/skills/workflow/SKILL.md`

```markdown
---
name: speckit.workflow
description: Defines the SpecKit branching strategy and Git workflow. Spec branches contain all design artifacts; task branches implement individual tasks with PRs back to spec branch; milestone completion triggers PR to main with tag and release.
---

# SpecKit Git Workflow

Structured branching strategy for specification-driven development.

## Branch Hierarchy

\`\`\`
main (protected)
├── spec/{feature-name}           # Specification branch (long-lived)
│   ├── specs/{feature}/spec.md
│   ├── specs/{feature}/plan.md
│   ├── specs/{feature}/tasks.md
│   └── ... other spec artifacts
│
└── task/{feature}/{task-id}      # Task implementation branches (short-lived)
    └── src/...                   # Implementation code
\`\`\`

## Branch Naming Conventions

| Branch Type | Pattern | Example |
|-------------|---------|---------|
| Main | \`main\` | \`main\` |
| Spec | \`spec/{feature-kebab-case}\` | \`spec/markdown-preview\` |
| Task | \`task/{feature}/{task-id}-{short-desc}\` | \`task/markdown-preview/T001-test-scaffolding\` |

## Workflow Phases

### Phase 1: Specification (on spec branch)

- \`/speckit.specify\` → Creates \`spec/{feature}\` branch, adds \`spec.md\`
- \`/speckit.plan\` → Adds \`plan.md\` on spec branch
- \`/speckit.tasks\` → Adds \`tasks.md\` on spec branch
- \`/speckit.issues\` → Creates GitHub issues from tasks

### Phase 2: Implementation (task branches)

For each task:
1. Create task branch from spec branch
2. Implement with TDD
3. Create PR to spec branch (linking issue)
4. Merge and cleanup

### Phase 3: Milestone Release

1. Verify all milestone issues closed
2. Update version and changelog
3. Create PR to main
4. After merge: tag and release
5. Close milestone

## Integration with SpecKit Commands

### /speckit.specify (modified behavior)

\`\`\`bash
git checkout main && git pull origin main
git checkout -b spec/{feature-name}
mkdir -p specs/{feature-name}
# ... generate spec.md ...
git add specs/{feature-name}/spec.md
git commit -m "docs({feature}): add feature specification"
git push -u origin spec/{feature-name}
\`\`\`

### /speckit.implement (modified behavior)

\`\`\`bash
git checkout spec/{feature}
git pull origin spec/{feature}
git checkout -b task/{feature}/T{id}-{slug}
# ... implement ...
git push -u origin task/{feature}/T{id}-{slug}
gh pr create --base spec/{feature} --title "[T{id}] {description}"
\`\`\`
```

---

## 2. Roadmap Skill

**File**: `.specify/skills/roadmap/SKILL.md`

```markdown
---
name: speckit.roadmap
description: Generate comprehensive roadmap documentation (docs/ROADMAP.md) from tasks.md with Mermaid visualizations, version milestones, and feature matrices. Use after /speckit.tasks to create public-facing project roadmap.
---

# Roadmap Generation Skill

Transform implementation tasks into professional roadmap documentation.

## Prerequisites

- \`specs/{feature}/tasks.md\` exists
- \`specs/{feature}/plan.md\` exists
- \`specs/{feature}/spec.md\` exists

## Outputs

### 1. docs/ROADMAP.md

- Executive summary
- Version milestones (v0.1.0 - v1.0.0)
- Feature tables per version
- Feature comparison matrix
- Architecture overview
- Success metrics
- Risk assessment
- Task summary

### 2. Roadmap Diagrams (embedded in docs/ROADMAP.md)

Mermaid visualizations:
- Timeline evolution
- Feature dependency graph
- User story dependencies
- Priority/effort quadrant
- User journey
- Sequence diagrams
- Gantt chart
- Task distribution pie charts

## Version Mapping

| Step Pattern | Version | Theme |
|--------------|---------|-------|
| Sprint 0 | Sprint 0 | Test Infrastructure |
| Foundational + US1 + US2 | v0.1.0 | MVP Core |
| US3 (next major feature) | v0.2.0 | Feature Enhancement |
| US4, US5 (access patterns) | v0.3.0 | Access / UX |
| US6 (configuration) | v0.4.0 | Configuration |
| Testing + Polish | v1.0.0 | Stable Release |
```

---

## 3. Issues Skill

**File**: `.specify/skills/issues/SKILL.md`

```markdown
---
name: speckit.issues
description: Create GitHub issues from tasks.md with proper milestones, labels, and project organization following VS Code extension community best practices.
---

# GitHub Issues Generation Skill

## Prerequisites

- \`specs/{feature}/tasks.md\` exists
- Git remote configured (GitHub)
- \`gh\` CLI authenticated

## Label Taxonomy

### Type Labels
| Label | Color | Description |
|-------|-------|-------------|
| \`type:feat\` | \`#1D76DB\` | New feature |
| \`type:fix\` | \`#D73A4A\` | Bug fix |
| \`type:docs\` | \`#0075CA\` | Documentation |
| \`type:test\` | \`#BFD4F2\` | Tests |
| \`type:chore\` | \`#EDEDED\` | Build/tooling |

### Priority Labels
| Label | Color | Description |
|-------|-------|-------------|
| \`priority:P0\` | \`#B60205\` | Critical |
| \`priority:P1\` | \`#D93F0B\` | High |
| \`priority:P2\` | \`#FBCA04\` | Medium |
| \`priority:P3\` | \`#C2E0C6\` | Low |

### Special Labels
| Label | Color | Description |
|-------|-------|-------------|
| \`epic\` | \`#3E4B9E\` | Parent issue |
| \`mvp\` | \`#0E8A16\` | MVP scope |
| \`good first issue\` | \`#7057FF\` | Beginner friendly |

## Milestone Structure

| Milestone | Description |
|-----------|-------------|
| v0.1.0 | MVP Core |
| v0.2.0 | Feature Theme |
| v0.3.0 | Enhancement Theme |
| v1.0.0 | Stable & Polished |

## Issue Template

\`\`\`markdown
## Task

{Task description}

## Context

- **Phase**: {Phase}
- **User Story**: {US#}

## Acceptance Criteria

{From spec}

## Dependencies

{Blocking tasks as issue links}
\`\`\`
```

---

## 4. Implement Skill

**File**: `.specify/skills/implement/SKILL.md`

```markdown
---
name: speckit.implement
description: Execute implementation tasks following the SpecKit branching workflow. Creates task branches from spec branch, implements with TDD, and creates PRs linking GitHub issues.
---

# Implementation Skill

## Prerequisites

- On \`spec/{feature}\` branch
- \`specs/{feature}/tasks.md\` exists
- GitHub issues created via \`/speckit.issues\`

## Inputs

- \`task_id\`: Single task (e.g., \`T001\`)
- \`range\`: Task range (e.g., \`T001-T011\`)
- \`phase\`: Phase number (e.g., \`1\`)

## Workflow Per Task

1. **Create task branch**: \`task/{feature}/T{id}-{slug}\`
2. **Write failing test** (TDD)
3. **Implement code**
4. **Verify tests pass**
5. **Commit and push**
6. **Create PR** to spec branch (linking issue)
7. **Post-merge cleanup**

## PR Template

\`\`\`markdown
## Summary

Implements task **T{id}** from tasks.md.

Fixes #{issue-number}

## Checklist

- [ ] Tests passing
- [ ] Code follows constitution
- [ ] JSDoc on public APIs
- [ ] Coverage ≥80%
\`\`\`

## Commit Convention

\`\`\`
{type}({scope}): {description}

Implements T{id}
Refs #{issue-number}
\`\`\`
```

---

## 5. Milestone Skill

**File**: `.specify/skills/milestone/SKILL.md`

```markdown
---
name: speckit.milestone
description: Complete a milestone by creating a release PR to main, tagging the release, and publishing to GitHub Releases.
---

# Milestone Completion Skill

## Prerequisites

- On \`spec/{feature}\` branch
- All milestone issues closed
- Clean working directory

## Inputs

- \`version\`: Semantic version (e.g., \`0.1.0\`)

## Phases

### 1. Pre-Flight Verification

- Verify on spec branch
- Check all milestone issues closed
- Verify clean working directory

### 2. Update README

- Update README.md so Features/Commands list only what is available in the release (no milestone/version mentions)

### 3. Update Version

- Update package.json
- Update CHANGELOG.md
- Commit version bump

### 4. Create Release PR

\`\`\`bash
gh pr create \\
  --base main \\
  --head spec/{feature} \\
  --title "Release v{version} - {theme}"
\`\`\`

### 5. Post-Merge Actions

\`\`\`bash
git checkout main && git pull
git tag -a v{version} -m "Release v{version}"
git push origin v{version}
gh release create v{version} --attach dist/*.vsix
\`\`\`

### 5. Close Milestone

\`\`\`bash
gh api repos/{owner}/{repo}/milestones/{n} -X PATCH -f state="closed"
\`\`\`
```

---

# Installation Script

Save as `.specify/skills/install.sh`:

```bash
#!/bin/bash
# SpecKit Skill Pack Installer

set -e

SKILLS_DIR=".specify/skills"

mkdir -p "$SKILLS_DIR"/{workflow,roadmap,issues,implement,milestone}

echo "Installing SpecKit skills..."

# Create skill files from embedded content
# (In practice, download from a URL or copy from template repo)

cat > "$SKILLS_DIR/workflow/SKILL.md" << 'SKILL_EOF'
# ... workflow skill content ...
SKILL_EOF

cat > "$SKILLS_DIR/roadmap/SKILL.md" << 'SKILL_EOF'
# ... roadmap skill content ...
SKILL_EOF

# ... repeat for other skills ...

echo "✅ SpecKit skills installed to $SKILLS_DIR/"
echo ""
echo "Available commands:"
echo "  /speckit.workflow  - View branching strategy"
echo "  /speckit.roadmap   - Generate roadmap from tasks"
echo "  /speckit.issues    - Create GitHub issues"
echo "  /speckit.implement - Implement tasks with branches"
echo "  /speckit.milestone - Complete milestone release"
```

---

# Alternative: Git Submodule

Add skills as a git submodule for easy updates:

```bash
# Add as submodule
git submodule add https://github.com/YOUR_USER/speckit-skills.git .specify/skills

# Update to latest
git submodule update --remote

# In new projects
git submodule init
git submodule update
```

---

# Alternative: Template Repository

1. Create a template repo with `.specify/skills/` pre-configured
2. When creating new projects, use "Use this template" on GitHub
3. Skills are automatically included

---

**License**: MIT
