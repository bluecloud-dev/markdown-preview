---
name: speckit.implement
description: |
  Execute implementation tasks with TDD workflow. Creates task branches from spec branch,
  implements with test-first approach, creates PRs linking GitHub issues.
  TRIGGER: When user says "implement", "start task", "work on T###".
  PREREQUISITE: On spec/{feature} branch, tasks.md exists, issues created.
model: sonnet
---

# Implementation Skill

Implement tasks following TDD workflow with task branches and PRs.

## Model Configuration

**Model**: Claude Sonnet 4.5
**Rationale**: Implementation is execution-focused:
- Single-file changes per task
- Fast TDD iteration cycles
- Explicit step-by-step instructions
- Speed for productivity

## Execution Protocol

**EXPLICIT INSTRUCTIONS** - Follow each step in order:

### Step 1: Pre-Implementation Setup

```bash
# 1. Get feature name from branch
feature_name=$(git branch --show-current | sed 's|spec/||')

# 2. Verify on spec branch
if [[ ! "$(git branch --show-current)" =~ ^spec/ ]]; then
  echo "❌ Must be on spec branch"
  echo "Run: git checkout spec/{feature}"
  exit 1
fi

# 3. Pull latest
git pull origin "spec/$feature_name"

# 4. Verify clean working directory
if [ -n "$(git status --porcelain)" ]; then
  echo "❌ Uncommitted changes. Stash or commit first."
  exit 1
fi

echo "✅ Ready to implement on spec/$feature_name"
```

### Step 2: Parse Task

```bash
task_id="$1"  # e.g., T001

# Find task in tasks.md
task_line=$(grep -E "^\- \[ \] $task_id " "specs/$feature_name/tasks.md")

if [ -z "$task_line" ]; then
  echo "❌ Task $task_id not found in tasks.md"
  exit 1
fi

# Extract components
task_desc=$(echo "$task_line" | sed -E 's/^- \[ \] T[0-9]+ //')
task_slug=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]' | tr ' ' '-' | cut -c1-30 | sed 's/-$//')
is_parallel=$(echo "$task_line" | grep -q '\[P\]' && echo "yes" || echo "no")
user_story=$(echo "$task_line" | grep -oP '\[US\d+\]' | tr -d '[]' || echo "")

# Find linked issue
issue_number=$(gh issue list --search "[${task_id}]" --json number --jq '.[0].number')

echo "📋 Task: $task_id"
echo "📝 $task_desc"
echo "🔗 Issue: ${issue_number:-none}"
```

### Step 3: Create Task Branch

```bash
task_branch="task/$feature_name/${task_id}-${task_slug}"

# Create branch from spec branch
git checkout -b "$task_branch"

echo "🌿 Branch: $task_branch"
```

### Step 4: TDD Cycle (MANDATORY)

**4.1 Write Failing Test FIRST**

Identify test file based on task:

| Task Pattern | Test File |
|--------------|-----------|
| "Create...test.ts" | Specified in task |
| Service implementation | `tests/unit/{service-name}.test.ts` |
| [US1] tasks | `tests/integration/preview-mode.test.ts` |
| [US2] tasks | `tests/integration/edit-mode.test.ts` |
| [US3] tasks | `tests/integration/formatting.test.ts` |

**Write test:**
```typescript
describe('{TaskID} {Short Description}', () => {
  it('should {expected behavior}', () => {
    // Arrange
    const input = /* test input */;

    // Act
    const result = /* call function */;

    // Assert
    expect(result).to.equal(/* expected */);
  });
});
```

**Verify test FAILS:**
```bash
npm test -- --grep "$task_id"
# MUST fail at this point
if [ $? -eq 0 ]; then
  echo "⚠️ Test passed before implementation - verify test is correct"
fi
```

**4.2 Implement Code**

Follow project patterns:
- Read existing code in target directory
- Match naming conventions (kebab-case files)
- Use VS Code native APIs (per constitution)
- TypeScript strict mode (no `any`)
- Add JSDoc to public functions

**4.3 Verify Tests Pass:**
```bash
npm test -- --grep "$task_id"
# MUST pass now

# Run full test suite
npm test

# Check lint
npm run lint
```

### Step 5: Commit and Push

```bash
# Determine commit type
commit_type="feat"
if echo "$task_desc" | grep -qiE "test|fixture"; then
  commit_type="test"
elif echo "$task_desc" | grep -qiE "doc|readme|changelog"; then
  commit_type="docs"
elif echo "$task_desc" | grep -qiE "config|setting|lint"; then
  commit_type="chore"
fi

# Determine scope from changed files
scope=$(git diff --cached --name-only | head -1 | sed -E 's|src/([^/]+)/.*|\1|')

# Commit
git add .
git commit -m "$commit_type($scope): ${task_desc:0:50}

Implements $task_id
${issue_number:+Refs #$issue_number}

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>"

# Push
git push -u origin "$task_branch"
```

### Step 6: Create Pull Request

```bash
pr_body=$(cat <<EOF
## Summary

Implements task **$task_id** from [tasks.md](specs/$feature_name/tasks.md).

${issue_number:+Fixes #$issue_number}

## Changes

$(git diff --stat spec/$feature_name..HEAD | head -15)

## Task Details

| Field | Value |
|-------|-------|
| Task ID | $task_id |
| User Story | ${user_story:-Infrastructure} |
| Parallel | $is_parallel |

## Checklist

- [x] Tests written and passing
- [ ] Code follows constitution
- [ ] JSDoc on public APIs
- [ ] No ESLint warnings

## Test Plan

\`\`\`bash
npm test -- --grep "$task_id"
\`\`\`

---
🤖 Generated with [Claude Code](https://claude.com/claude-code)
EOF
)

pr_url=$(gh pr create \
  --base "spec/$feature_name" \
  --head "$task_branch" \
  --title "[$task_id] ${task_desc:0:60}" \
  --body "$pr_body")

echo "✅ PR: $pr_url"
```

### Step 7: Update Progress

```bash
# Add in-progress label to issue
if [ -n "$issue_number" ]; then
  gh issue edit "$issue_number" --add-label "status:in-progress"
fi

# Save checkpoint
mkdir -p .specify/cache
echo "{\"task\":\"$task_id\",\"branch\":\"$task_branch\",\"pr\":\"$pr_url\",\"status\":\"pr_open\"}" \
  > ".specify/cache/task-$task_id.json"
```

### Step 8: Post-Merge Cleanup

After PR is merged:

```bash
# Return to spec branch
git checkout "spec/$feature_name"
git pull origin "spec/$feature_name"

# Delete task branch
git branch -d "$task_branch"

# Update issue
if [ -n "$issue_number" ]; then
  gh issue edit "$issue_number" \
    --remove-label "status:in-progress"
fi

# Mark complete in tasks.md
sed -i '' "s/- \[ \] $task_id/- [x] $task_id/" "specs/$feature_name/tasks.md"
git add "specs/$feature_name/tasks.md"
git commit -m "docs: mark $task_id complete"
git push

echo "✅ $task_id complete!"
```

## Batch Mode

For implementing multiple tasks:

```bash
# Range: T001-T011
for i in $(seq 1 11); do
  task_id=$(printf "T%03d" $i)
  echo "━━━ Implementing $task_id ━━━"

  # Implement task
  speckit_implement "$task_id"

  # Wait for merge if not auto-merge
  echo "PR created. Continue? (y/n)"
  read -r answer
  [ "$answer" != "y" ] && break
done
```

## Validation Checkpoints

After EACH step, verify:

| Step | Validation |
|------|------------|
| 1 | On spec branch, clean directory |
| 2 | Task exists in tasks.md |
| 3 | Branch created successfully |
| 4.1 | Test fails before implementation |
| 4.3 | All tests pass, lint clean |
| 5 | Commit created, pushed |
| 6 | PR created successfully |

**If any validation fails: STOP and report error.**

## Error Recovery

| Error | Action |
|-------|--------|
| Branch exists | `git checkout $branch` or delete and recreate |
| Tests fail after impl | Fix implementation, re-run tests |
| Lint errors | Run `npm run lint -- --fix`, verify |
| Push rejected | Pull and rebase: `git pull --rebase origin spec/$feature` |
| PR conflict | Rebase on spec branch |

## Output

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Task Implementation Complete
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Task: T001 - Create test scaffolding
Branch: task/markdown-preview/T001-create-test-scaffolding
PR: https://github.com/user/repo/pull/15
Issue: #1 (linked)

Tests: ✅ Passing
Lint: ✅ Clean
Coverage: 85%

Next: Merge PR, then run /speckit.implement T002
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
