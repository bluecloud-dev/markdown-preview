# Claude Model Optimization for SpecKit

**Analysis Date**: 2025-12-26
**Based On**: Official Anthropic documentation, community best practices, and empirical feedback

## Executive Summary

This document defines the optimal model selection and prompting strategies for SpecKit skills, based on comprehensive research of Claude Opus 4.5 and Sonnet 4.5 capabilities.

### Model Assignment

| Command Type | Model | Rationale |
|-------------|-------|-----------|
| **Thinking Commands** | Opus 4.5 | Superior reasoning, architecture, fewer tokens for complex tasks |
| `/speckit.specify` | Opus | Requirements analysis, edge case discovery |
| `/speckit.clarify` | Opus | Ambiguity detection, targeted questions |
| `/speckit.plan` | Opus | Architecture decisions, trade-off analysis |
| `/speckit.tasks` | Opus | Dependency ordering, parallel opportunity detection |
| `/speckit.roadmap` | Opus | Strategic synthesis, multi-artifact correlation |
| `/speckit.analyze` | Opus | Cross-artifact consistency, gap detection |
| **Execution Commands** | Sonnet 4.5 | Speed, cost-efficiency, routine operations |
| `/speckit.implement` | Sonnet | TDD cycles, single-file changes |
| `/speckit.issues` | Sonnet | API calls, template application |
| `/speckit.milestone` | Sonnet | Git operations, release automation |
| `/speckit.taskstoissues` | Sonnet | Bulk issue creation, label application |

---

## Research Findings

### Opus 4.5 Strengths (Verified)

| Capability | Evidence | Source |
|-----------|----------|--------|
| Long-horizon reasoning | 15% improvement over Sonnet on TerminalBench | [Anthropic](https://www.anthropic.com/news/claude-opus-4-5) |
| Token efficiency | 48-76% fewer tokens for equivalent results | [Anthropic](https://www.anthropic.com/news/claude-opus-4-5) |
| Multi-file architecture | Leads 7/8 languages on SWE-bench Multilingual | [Anthropic](https://www.anthropic.com/news/claude-opus-4-5) |
| Fewer errors | 50-75% reduction in tool calling and build errors | [ClaudeLog](https://claudelog.com/faqs/claude-4-sonnet-vs-opus/) |
| Ambiguity handling | Reasons about trade-offs without hand-holding | [Anthropic](https://www.anthropic.com/news/claude-opus-4-5) |

### Sonnet 4.5 Strengths (Verified)

| Capability | Evidence | Source |
|-----------|----------|--------|
| Speed | Fast enough for real-time autocomplete | [ClaudeLog](https://claudelog.com/faqs/claude-4-sonnet-vs-opus/) |
| Cost efficiency | Significantly cheaper per token than Opus | [ClaudeLog](https://claudelog.com/faqs/claude-4-sonnet-vs-opus/) |
| Routine coding | Excellent for feature implementation | [Anthropic Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices) |
| Sustained workloads | Can sustain 30+ hour agentic workflows | [ClaudeLog](https://claudelog.com/faqs/claude-4-sonnet-vs-opus/) |
| Instruction following | Superior precision on explicit instructions | [Skywork](https://skywork.ai/blog/claude-sonnet-4-5-vs-claude-opus-which-one-should-you-choose/) |

---

## Prompting Patterns

### For Opus (Thinking Commands)

#### 1. Extended Thinking Triggers

```
Thinking level hierarchy:
"think" < "think hard" < "think harder" < "ultrathink"

Token budgets:
- "think": ~4,000 tokens
- "ultrathink": ~31,999 tokens
```

**Recommendation**: Use "think hard" for spec/plan, "ultrathink" for complex analysis.

#### 2. High-Level Over Prescriptive

**Bad (Prescriptive)**:
```
Step 1: Read the spec
Step 2: Identify requirements
Step 3: Create plan sections
Step 4: ...
```

**Good (High-Level)**:
```
Think deeply about the feature requirements. Consider multiple architectural
approaches and their trade-offs. Analyze edge cases thoroughly before
recommending an approach.
```

**Source**: [Extended Thinking Tips](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/extended-thinking-tips)

#### 3. Self-Verification Pattern

```markdown
Before finalizing, verify your analysis:
1. Have you considered all edge cases from the spec?
2. Do your recommendations align with the constitution?
3. Are there gaps or ambiguities you should flag?
Fix any issues before presenting the final output.
```

#### 4. Constraint Optimization

Opus excels when given multiple constraints to balance:

```markdown
Generate a plan that satisfies ALL constraints:
- Must use native VS Code APIs (P-NI principle)
- Must achieve <50ms startup impact (NFR-002)
- Must maintain 80% test coverage (NFR-007)
- Must respect existing architecture patterns
Consider trade-offs explicitly when constraints conflict.
```

### For Sonnet (Execution Commands)

#### 1. Explicit Instructions

**Bad (Vague)**:
```
Add tests for the service
```

**Good (Explicit)**:
```
Write unit tests for ValidationService in tests/unit/validation-service.test.ts:
- Test isMarkdownFile() with .md, .txt, .markdown extensions
- Test isDiffView() with git diff URIs
- Test isLargeFile() with files at, below, and above 1MB threshold
Use Mocha + Chai + Sinon. Mock vscode.workspace.fs.stat.
```

**Source**: [Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)

#### 2. TDD Cycle Enforcement

```markdown
For each task:
1. FIRST write the failing test - verify it fails
2. THEN implement the minimum code to pass
3. Commit test + implementation together
Do NOT skip the failure verification step.
```

#### 3. Validation Checkpoints

```markdown
After each operation:
- [ ] Run `npm run lint` - fix any errors
- [ ] Run `npm test` - ensure tests pass
- [ ] Verify no TypeScript errors with `tsc --noEmit`
Stop and report if any check fails.
```

---

## Skill Activation Optimization

### Problem: Low Activation Rates

Simple skill descriptions achieve only 20-50% activation. Claude acknowledges skills passively but ignores them.

### Solution: Forced Evaluation Pattern

**Source**: [Scott Spence - Making Skills Activate Reliably](https://scottspence.com/posts/how-to-make-claude-code-skills-activate-reliably)

```markdown
MANDATORY: Before proceeding, you MUST:

Step 1 - EVALUATE: For each available skill, state YES/NO with reason:
- speckit.specify: YES/NO because...
- speckit.plan: YES/NO because...

Step 2 - ACTIVATE: If any skill applies, use Skill() tool NOW.

Step 3 - IMPLEMENT: Only proceed after skill activation completes.

The evaluation is WORTHLESS unless you ACTIVATE matching skills.
```

**Result**: 80-84% activation success vs 20-50% baseline.

### Description Optimization

**Weak Description**:
```
Generate a roadmap from tasks
```

**Strong Description**:
```
Generate comprehensive roadmap documentation (docs/ROADMAP.md)
from tasks.md. TRIGGER: After /speckit.tasks completes OR when user mentions
"roadmap", "milestone planning", "release schedule", or "feature timeline".
PREREQUISITE: specs/{feature}/tasks.md must exist.
```

---

## Anti-Patterns to Avoid

### 1. Wrong Model for Task

| Task | Wrong Choice | Right Choice | Why |
|------|-------------|--------------|-----|
| Architecture planning | Sonnet | Opus | Needs deep trade-off analysis |
| Bulk issue creation | Opus | Sonnet | Routine API calls, speed matters |
| Edge case discovery | Sonnet | Opus | Requires creative reasoning |
| Single file edit | Opus | Sonnet | Overkill, wastes tokens |

### 2. Over-Prescriptive Opus Prompts

Opus performs WORSE with step-by-step instructions. Its creativity exceeds human-prescribed thinking processes.

### 3. Vague Sonnet Instructions

Sonnet needs explicit, specific instructions. Ambiguity leads to course corrections and wasted iterations.

### 4. Missing Verification Steps

Both models benefit from explicit "verify your work" instructions, but Opus naturally self-checks while Sonnet needs explicit prompts.

---

## Implementation Checklist

### For Each Thinking Skill (Opus)

- [ ] Add `model: opus` to YAML frontmatter
- [ ] Use "think hard" or "ultrathink" trigger in prompt
- [ ] Frame requirements as constraints to balance
- [ ] Request self-verification before output
- [ ] Avoid step-by-step prescriptive instructions
- [ ] Include cross-artifact references for context

### For Each Execution Skill (Sonnet)

- [ ] Add `model: sonnet` to YAML frontmatter
- [ ] Use explicit, specific instructions
- [ ] Define clear validation checkpoints
- [ ] Include TDD enforcement where applicable
- [ ] Add error handling guidance
- [ ] Request confirmation before destructive actions

---

## Token Budget Recommendations

### Opus Extended Thinking

| Task Complexity | Trigger | Approx. Tokens |
|-----------------|---------|----------------|
| Simple analysis | "think" | 4,000 |
| Moderate planning | "think hard" | 10,000-16,000 |
| Complex architecture | "think harder" | 20,000-25,000 |
| Multi-artifact synthesis | "ultrathink" | 31,999 |

### Sonnet Context Efficiency

- Keep skill prompts under 2,000 tokens
- Use external file references instead of inline content
- Clear context with `/clear` between major phases

---

## Sources

### Official Anthropic

- [Claude Opus 4.5 Introduction](https://www.anthropic.com/news/claude-opus-4-5)
- [Claude Code Best Practices](https://www.anthropic.com/engineering/claude-code-best-practices)
- [Extended Thinking Tips](https://platform.claude.com/docs/en/build-with-claude/prompt-engineering/extended-thinking-tips)
- [Multi-Agent Research System](https://www.anthropic.com/engineering/multi-agent-research-system)

### Community Best Practices

- [ClaudeLog: Sonnet vs Opus Comparison](https://claudelog.com/faqs/claude-4-sonnet-vs-opus/)
- [6 Months of Hardcore Claude Code Use](https://dev.to/diet-code103/claude-code-is-a-beast-tips-from-6-months-of-hardcore-use-572n)
- [Making Skills Activate Reliably](https://scottspence.com/posts/how-to-make-claude-code-skills-activate-reliably)
- [Claude Code Customization Guide](https://alexop.dev/posts/claude-code-customization-guide-claudemd-skills-subagents/)
- [Skywork: Sonnet vs Opus Choice](https://skywork.ai/blog/claude-sonnet-4-5-vs-claude-opus-which-one-should-you-choose/)

---

**Version**: 1.0.0
