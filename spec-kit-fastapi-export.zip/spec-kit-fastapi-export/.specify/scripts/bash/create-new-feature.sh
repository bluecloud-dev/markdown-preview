#!/usr/bin/env bash

set -e

JSON_MODE=false
SHORT_NAME=""
PREFIX=""
ARGS=()
i=1
while [ $i -le $# ]; do
    arg="${!i}"
    case "$arg" in
        --json)
            JSON_MODE=true
            ;;
        --short-name)
            if [ $((i + 1)) -gt $# ]; then
                echo 'Error: --short-name requires a value' >&2
                exit 1
            fi
            i=$((i + 1))
            next_arg="${!i}"
            if [[ "$next_arg" == --* ]]; then
                echo 'Error: --short-name requires a value' >&2
                exit 1
            fi
            SHORT_NAME="$next_arg"
            ;;
        --prefix)
            if [ $((i + 1)) -gt $# ]; then
                echo 'Error: --prefix requires a value' >&2
                exit 1
            fi
            i=$((i + 1))
            next_arg="${!i}"
            if [[ "$next_arg" == --* ]]; then
                echo 'Error: --prefix requires a value' >&2
                exit 1
            fi
            PREFIX="$next_arg"
            ;;
        --number)
            echo "Error: --number is no longer supported. Use feature/<name> or feat/<name> instead." >&2
            exit 1
            ;;
        --help|-h)
            echo "Usage: $0 [--json] [--short-name <name>] [--prefix <feature|feat>] <feature_description>"
            echo ""
            echo "Options:"
            echo "  --json               Output in JSON format"
            echo "  --short-name <name>  Provide a custom short name (2-4 words) for the branch"
            echo "  --prefix <feature|feat>  Branch prefix (default: feature)"
            echo "  --help, -h           Show this help message"
            echo ""
            echo "Examples:"
            echo "  $0 'Add user authentication system' --short-name 'user-auth'"
            echo "  $0 'Implement OAuth2 integration for API' --prefix feat"
            exit 0
            ;;
        *)
            ARGS+=("$arg")
            ;;
    esac
    i=$((i + 1))
done

FEATURE_DESCRIPTION="${ARGS[*]}"
if [ -z "$FEATURE_DESCRIPTION" ]; then
    echo "Usage: $0 [--json] [--short-name <name>] [--prefix <feature|feat>] <feature_description>" >&2
    exit 1
fi

# Function to find the repository root by searching for existing project markers
find_repo_root() {
    local dir="$1"
    while [ "$dir" != "/" ]; do
        if [ -d "$dir/.git" ] || [ -d "$dir/.specify" ]; then
            echo "$dir"
            return 0
        fi
        dir="$(dirname "$dir")"
    done
    return 1
}

# Function to clean and format a branch name
clean_branch_name() {
    local name="$1"
    echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/-/g' | sed 's/-\+/-/g' | sed 's/^-//' | sed 's/-$//'
}

# Function to generate branch name with stop word filtering and length filtering
generate_branch_name() {
    local description="$1"

    # Common stop words to filter out
    local stop_words="^(i|a|an|the|to|for|of|in|on|at|by|with|from|is|are|was|were|be|been|being|have|has|had|do|does|did|will|would|should|could|can|may|might|must|shall|this|that|these|those|my|your|our|their|want|need|add|get|set)$"

    # Convert to lowercase and split into words
    local clean_name
    clean_name=$(echo "$description" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9]/ /g')

    # Filter words: remove stop words and words shorter than 3 chars (unless they're uppercase acronyms in original)
    local meaningful_words=()
    for word in $clean_name; do
        [ -z "$word" ] && continue

        if ! echo "$word" | grep -qiE "$stop_words"; then
            if [ ${#word} -ge 3 ]; then
                meaningful_words+=("$word")
            elif echo "$description" | grep -q "\b${word^^}\b"; then
                meaningful_words+=("$word")
            fi
        fi
    done

    if [ ${#meaningful_words[@]} -gt 0 ]; then
        local max_words=3
        if [ ${#meaningful_words[@]} -eq 4 ]; then max_words=4; fi

        local result=""
        local count=0
        for word in "${meaningful_words[@]}"; do
            if [ $count -ge $max_words ]; then break; fi
            if [ -n "$result" ]; then result="$result-"; fi
            result="$result$word"
            count=$((count + 1))
        done
        echo "$result"
    else
        local cleaned
        cleaned=$(clean_branch_name "$description")
        echo "$cleaned" | tr '-' '\n' | grep -v '^$' | head -3 | tr '\n' '-' | sed 's/-$//'
    fi
}

# Resolve repository root. Prefer git information when available, but fall back
# to searching for repository markers so the workflow still functions in repositories that
# were initialised with --no-git.
SCRIPT_DIR="$(CDPATH="" cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if git rev-parse --show-toplevel >/dev/null 2>&1; then
    REPO_ROOT=$(git rev-parse --show-toplevel)
    HAS_GIT=true
else
    REPO_ROOT="$(find_repo_root "$SCRIPT_DIR")"
    if [ -z "$REPO_ROOT" ]; then
        echo "Error: Could not determine repository root. Please run this script from within the repository." >&2
        exit 1
    fi
    HAS_GIT=false
fi

cd "$REPO_ROOT"

SPECS_DIR="$REPO_ROOT/specs"
mkdir -p "$SPECS_DIR"

BRANCH_PREFIX="${SPECIFY_FEATURE_PREFIX:-${SPECIFY_BRANCH_PREFIX:-feature}}"
if [ -n "$PREFIX" ]; then
    BRANCH_PREFIX="$PREFIX"
fi
BRANCH_PREFIX="${BRANCH_PREFIX%/}"
BRANCH_PREFIX=$(echo "$BRANCH_PREFIX" | tr '[:upper:]' '[:lower:]')
case "$BRANCH_PREFIX" in
    feature|feat)
        ;;
    *)
        echo "Error: --prefix must be 'feature' or 'feat' (got '$BRANCH_PREFIX')" >&2
        exit 1
        ;;
esac

# Generate branch slug
if [ -n "$SHORT_NAME" ]; then
    BRANCH_BASE_SLUG=$(clean_branch_name "$SHORT_NAME")
else
    BRANCH_BASE_SLUG=$(generate_branch_name "$FEATURE_DESCRIPTION")
fi

if [ -z "$BRANCH_BASE_SLUG" ]; then
    echo "Error: Could not derive a feature slug from description. Provide --short-name." >&2
    exit 1
fi

MAX_BRANCH_LENGTH=244

branch_exists() {
    local branch="$1"
    git show-ref --verify --quiet "refs/heads/$branch" && return 0
    git show-ref --verify --quiet "refs/remotes/origin/$branch" && return 0
    return 1
}

build_candidate() {
    local base_slug="$1"
    local prefix="$2"
    local suffix_num="$3"
    local suffix=""

    if [ "$suffix_num" -gt 1 ]; then
        suffix="-$suffix_num"
    fi

    local max_slug_len=$((MAX_BRANCH_LENGTH - ${#prefix} - 1 - ${#suffix}))
    if [ "$max_slug_len" -lt 1 ]; then
        echo "Error: Branch prefix too long to build a valid name." >&2
        exit 1
    fi

    local truncated_slug="$base_slug"
    local truncated_flag="false"
    if [ ${#truncated_slug} -gt $max_slug_len ]; then
        truncated_slug=$(echo "$truncated_slug" | cut -c1-$max_slug_len | sed 's/-$//')
        truncated_flag="true"
    fi

    if [ -z "$truncated_slug" ]; then
        echo "Error: Feature slug is empty after trimming. Provide a shorter --short-name." >&2
        exit 1
    fi

    local slug="${truncated_slug}${suffix}"
    local branch="${prefix}/${slug}"

    printf '%s\t%s\t%s\n' "$branch" "$slug" "$truncated_flag"
}

suffix_num=1
candidate_branch=""
candidate_slug=""
truncated_flag="false"
while true; do
    IFS=$'\t' read -r candidate_branch candidate_slug truncated_flag < <(build_candidate "$BRANCH_BASE_SLUG" "$BRANCH_PREFIX" "$suffix_num")

    if [ "$HAS_GIT" = true ] && branch_exists "$candidate_branch"; then
        suffix_num=$((suffix_num + 1))
        continue
    fi

    if [ -d "$SPECS_DIR/$candidate_slug" ]; then
        suffix_num=$((suffix_num + 1))
        continue
    fi

    break
done

if [ "$suffix_num" -gt 1 ]; then
    >&2 echo "[specify] Notice: Branch name exists; using $candidate_branch"
fi

if [ "$truncated_flag" = "true" ]; then
    >&2 echo "[specify] Warning: Branch slug truncated to meet GitHub's 244-byte limit"
fi

BRANCH_NAME="$candidate_branch"
FEATURE_SLUG="$candidate_slug"

if [ "$HAS_GIT" = true ]; then
    git checkout -b "$BRANCH_NAME"
else
    >&2 echo "[specify] Warning: Git repository not detected; skipped branch creation for $BRANCH_NAME"
fi

FEATURE_DIR="$SPECS_DIR/$FEATURE_SLUG"
mkdir -p "$FEATURE_DIR"

TEMPLATE="$REPO_ROOT/.specify/templates/spec-template.md"
SPEC_FILE="$FEATURE_DIR/spec.md"
if [ -f "$TEMPLATE" ]; then cp "$TEMPLATE" "$SPEC_FILE"; else touch "$SPEC_FILE"; fi

# Set the SPECIFY_FEATURE environment variable for the current session
export SPECIFY_FEATURE="$BRANCH_NAME"

if $JSON_MODE; then
    printf '{"BRANCH_NAME":"%s","SPEC_FILE":"%s","FEATURE_DIR":"%s","FEATURE_SLUG":"%s"}\n' \
        "$BRANCH_NAME" "$SPEC_FILE" "$FEATURE_DIR" "$FEATURE_SLUG"
else
    echo "BRANCH_NAME: $BRANCH_NAME"
    echo "SPEC_FILE: $SPEC_FILE"
    echo "FEATURE_DIR: $FEATURE_DIR"
    echo "FEATURE_SLUG: $FEATURE_SLUG"
    echo "SPECIFY_FEATURE environment variable set to: $BRANCH_NAME"
fi
