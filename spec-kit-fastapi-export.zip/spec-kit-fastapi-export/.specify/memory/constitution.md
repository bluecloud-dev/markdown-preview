---
description: Project constitution and governance rules for the Markdown Reader VS Code extension
globs:
  - "**/*.ts"
  - "**/*.json"
  - "src/**/*"
  - "tests/**/*"
alwaysApply: true
priority: 1
---

# Project Constitution: Markdown Preview Default Extension

## Project Overview

This is a VS Code extension that opens markdown files in rendered preview mode by default, optimizing the reading experience for developers reviewing AI-generated documentation. Users can toggle to edit mode (split view with live preview) and format text using toolbar, context menu, or keyboard shortcuts.

## Quick Reference for AI Agents

### Priority Hierarchy (Numbered by Importance)

| Priority | Rule | Enforcement |
|----------|------|-------------|
| **P1** | Use native VS Code APIs | MANDATORY - No custom webviews/parsers |
| **P2** | Test-first development | MANDATORY - Write tests before code |
| **P3** | TypeScript strict mode | MANDATORY - No `any` without justification |
| **P4** | Performance (<50ms startup) | MANDATORY - Lazy activation required |
| **P5** | Documentation (JSDoc) | REQUIRED - All public APIs documented |
| **P6** | Accessibility (ARIA) | REQUIRED - All UI elements labeled |

### MANDATORY Rules (Never Violate)

| Rule | Validation |
|------|------------|
| Use `markdown.showPreview` for rendering | Check: no `createWebviewPanel` calls |
| Achieve 80% test coverage | Check: coverage report meets threshold |
| Add <50ms to startup | Check: lazy activation via `onLanguage:markdown` |
| TypeScript strict mode | Check: `"strict": true` in tsconfig.json |
| JSDoc on public APIs | Check: all exported functions documented |

### PROHIBITED (Stop Immediately if Attempted)

- **NEVER** create custom webviews for markdown rendering
- **NEVER** collect telemetry or send data externally
- **NEVER** auto-return to preview mode on file save
- **NEVER** use `any` types without justification comment
- **NEVER** use `console.log` in production code
- **NEVER** ignore Promise rejections
- **NEVER** use synchronous file operations

### Extended Thinking Triggers

Use extended reasoning (think step-by-step) when:

| Scenario | Trigger Phrase | What to Analyze |
|----------|----------------|-----------------|
| Architecture decisions | "Think through the trade-offs..." | Pros/cons of each approach |
| Complex state management | "Analyze carefully how state flows..." | Race conditions, edge cases |
| Performance optimization | "Consider the performance implications..." | Bottlenecks, lazy loading options |
| API design | "Think through the consumer experience..." | Usability, consistency, extensibility |
| Error handling strategy | "Analyze what could go wrong..." | Failure modes, recovery paths |

**IMPORTANT**: For non-trivial decisions, explicitly write out your reasoning before implementing.

### Self-Check Questions

Before completing any task, ask yourself:

1. **Native API?** "Is there a VS Code API that already does this?"
2. **Simpler way?** "Is there a simpler approach I'm overlooking?"
3. **Test first?** "Did I write a failing test before this implementation?"
4. **Scope creep?** "Am I adding functionality not in the spec?"
5. **Over-engineering?** "Will this abstraction be used more than once?"
6. **User impact?** "Does this respect user intent and workflow?"

### Quick Validation Checklist

Before completing any task, verify:
- [ ] Uses VS Code native APIs where available
- [ ] No custom webview or markdown parser created
- [ ] Tests written before implementation (TDD)
- [ ] All disposables registered with `context.subscriptions`
- [ ] ARIA labels on UI elements

---

## Core Development Principles

### I. Reading-First Experience {#P-RF}

The primary use case is **reading**, not editing. Every design decision must optimize for the reading experience first.

#### Design Philosophy

**MANDATORY: Preview by Default**

When a markdown file opens, it MUST display in rendered preview mode. The raw markdown editor is a secondary, on-demand feature.

| Scenario | Expected Behavior |
|----------|-------------------|
| Click .md in explorer | Opens in preview mode |
| Ctrl+P → select .md | Opens in preview mode |
| Go to Definition → .md | Opens in preview mode |
| New untitled .md | Opens in edit mode (no content to preview) |
| File in excluded path | Opens in text editor (respects config) |
| Diff view | Not intercepted; VS Code handles normally |
| Large file (>1MB) | Opens in text editor with info message |
| Git conflict markers | Opens in edit mode to allow resolution |
| Binary .md file | Show error gracefully; don't crash |
| Files via terminal | Same preview-by-default behavior |
| Multiple files open | Each file has independent state |

**Implementation Approach**:

```typescript
// Intercept file opens and redirect to preview
workspace.onDidOpenTextDocument(async (document) => {
  if (!isMarkdownDocument(document)) return;
  if (!shouldShowPreview(document)) return;

  // Close the text editor that just opened
  await commands.executeCommand('workbench.action.closeActiveEditor');

  // Open the native markdown preview instead
  await commands.executeCommand('markdown.showPreview', document.uri);
});
```

**Why Preview First**:

- Developers often review documentation without needing to edit
- Raw markdown syntax is visual noise when reading
- AI-generated docs are primarily consumed, not edited
- Preview mode is the natural way humans read formatted text

#### UI Minimalism in Preview Mode

**MANDATORY: Zero UI Additions in Preview Mode**

When in preview mode, the extension adds NOTHING visible to the UI:

- No toolbar icons
- No status bar items (beyond what VS Code shows)
- No floating buttons
- No overlays or decorations

The user should not know the extension exists until they need to edit.

```typescript
// Toolbar visibility controlled by context key
"when": "markdownReader.editMode && resourceLangId == markdown"
```

---

### II. Native Integration {#P-NI}

Use VS Code's built-in capabilities. Do NOT reinvent features that VS Code provides.

#### What to Use from VS Code

| Feature | VS Code Native API | Our Extension |
|---------|-------------------|---------------|
| Markdown rendering | `markdown.showPreview` command | ✅ Use it |
| Syntax highlighting | Built-in markdown grammar | ✅ Use it |
| Live preview sync | Native markdown preview | ✅ Use it |
| Theme support | User's selected theme | ✅ Use it |
| Custom renderer | Custom webview | ❌ Never |
| Custom parser | markdown-it plugin | ❌ Never |

#### Forbidden Patterns

**NEVER** create:

- Custom webviews for markdown rendering
- Custom markdown parsers or renderers
- Custom CSS for preview styling
- Custom theme handling
- Inline preview in the editor

**ALWAYS** use:

- `markdown.showPreview` / `markdown.showPreviewToSide`
- `ViewColumn` for split view management
- Native `TextEditorEdit` for formatting operations
- VS Code's configuration API

```typescript
// GOOD: Use native preview
await commands.executeCommand('markdown.showPreview', uri);

// BAD: Custom webview
const panel = vscode.window.createWebviewPanel(
  'markdownPreview',        // ❌ Don't do this
  'Preview',
  vscode.ViewColumn.One,
  { enableScripts: true }   // ❌ Security risk
);
```

---

### III. Zero-Configuration Default {#P-ZC}

The extension MUST work perfectly immediately after installation. No setup required.

#### Default Behavior

| Setting | Default Value | Rationale |
|---------|---------------|-----------|
| `enabled` | `true` | Extension should work immediately |
| `excludePatterns` | `["**/node_modules/**", "**/.git/**"]` | Sensible exclusions |
| `maxFileSize` | `1048576` (1MB) | Performance protection |

#### First-Time User Experience

1. Install extension → No required prompts; a one-time welcome message with an optional US1 tutorial is allowed
2. Click any .md file → Opens in preview mode (success!)
3. No configuration needed for 90% of users

**Welcome/Tutorial Constraints**:
- Must be non-blocking and dismissible
- Must not require any configuration to achieve preview-by-default behavior
- Must only appear once per user (tracked via local state)

```typescript
// Configuration with sensible defaults
interface ExtensionConfiguration {
  enabled: boolean;                    // Default: true
  excludePatterns: string[];           // Default: ["**/node_modules/**", "**/.git/**"]
  maxFileSize: number;                 // Default: 1MB
}

function getDefaultConfig(): ExtensionConfiguration {
  return {
    enabled: true,
    excludePatterns: ['**/node_modules/**', '**/.git/**'],
    maxFileSize: 1_048_576
  };
}
```

#### Configuration Discovery

Settings should be discoverable but not required:

- Settings appear in VS Code's Settings UI
- Clear descriptions for each setting
- Examples in setting descriptions
- No "getting started" wizard

---

### IV. Non-Intrusive Design {#P-ND}

The extension must never interfere with the user's workflow or existing habits.

#### Escape Hatches

Users can always return to normal VS Code behavior:

| Action | Result |
|--------|--------|
| Disable extension | All .md files open normally |
| Add exclude pattern | Specific paths open normally |
| Press Escape in preview | Normal VS Code behavior |
| Open via "Open With" | User controls the editor |

#### Respecting User Intent

```typescript
// If user manually opens text editor, respect their choice
function shouldShowPreview(document: TextDocument): boolean {
  // Don't intercept if user explicitly chose text editor
  if (userExplicitlyOpenedTextEditor()) return false;

  // Don't intercept diff views
  if (isDiffView(document)) return false;

  // Don't intercept files in excluded paths
  if (isExcludedPath(document.uri)) return false;

  return true;
}
```

#### No Auto-Return on Save

**CRITICAL**: When user is in edit mode and saves the file:

- ✅ Stay in edit mode (user is still working)
- ❌ Auto-return to preview (disruptive)

```typescript
// We do NOT register onDidSaveTextDocument to auto-close text editor
// The user explicitly entered edit mode; let them leave explicitly
```

#### Toolbar Visibility

Formatting toolbar is ONLY visible when:

1. File is markdown (`resourceLangId == markdown`)
2. Edit mode is active (`markdownReader.editMode == true`)
3. User is in the text editor (not preview pane)

---

### V. Production-Quality Code {#P-PQ}

The codebase must be exemplary, maintainable and serve as a learning resource.

#### Language Configuration

- **Language**: TypeScript 5.x with strict mode (`"strict": true`)
- **Target**: ES2022
- **Module**: CommonJS (VS Code extension requirement)

#### Type Safety

- No `any` types except when absolutely unavoidable (must be justified in comments)
- Use discriminated unions for state management
- Define explicit interfaces for all data structures
- Use `unknown` instead of `any` for uncertain types, then narrow with type guards

```typescript
// Use discriminated unions for state
enum ViewMode {
  Preview = 'preview',
  Edit = 'edit'
}

interface FileState {
  uri: string;
  mode: ViewMode;
  lastModeChange: number;
}

// No `any` types - use `unknown` and narrow
function handleUnknownInput(input: unknown): string {
  if (typeof input === 'string') {
    return input;
  }
  throw new Error('Expected string input');
}
```

#### Code Organization

```
src/
├── extension.ts              # Entry point only (activate/deactivate)
├── commands/                 # Command handlers
│   ├── mode-commands.ts      # enterEditMode, exitEditMode, toggleEditMode
│   └── format-commands.ts    # bold, italic, strikethrough, list, code, link, heading
├── services/                 # Business logic
│   ├── preview-service.ts    # showPreview, enterEditMode, exitEditMode logic
│   ├── state-service.ts      # Per-file edit/preview state management
│   ├── formatting-service.ts # Text transformation logic (wrap, toggle prefix)
│   ├── config-service.ts     # Settings access (enabled, excludePatterns, maxFileSize)
│   └── validation-service.ts # File size check, diff view detection, exclusion matching
├── handlers/                 # Event handlers
│   └── markdown-file-handler.ts  # onDidOpenTextDocument interception
├── ui/                       # UI controllers
│   └── title-bar-controller.ts   # Done button, formatting toolbar visibility
└── types/                    # Type definitions
    ├── state.ts              # ViewMode enum, FileState interface
    ├── config.ts             # ExtensionConfiguration interface
    └── formatting.ts         # FormattingAction interface
```

#### Function Design

- **Single responsibility**: One function does one thing
- **Maximum 30 lines** per function (excluding comments)
- **Maximum 3 parameters**; use options object for more
- **Pure functions** preferred where possible
- **Explicit return types** for all public APIs

#### Error Handling

- Create custom error classes extending `Error`
- Never swallow errors silently
- Provide user-friendly error messages with actionable guidance
- Log technical details for debugging while showing simple messages to users

#### Naming Conventions

| Element | Convention | Example |
|---------|------------|---------|
| Files | kebab-case | `preview-service.ts` |
| Classes/Interfaces | PascalCase | `PreviewService` |
| Functions/Variables | camelCase | `showPreview` |
| Constants | SCREAMING_SNAKE_CASE | `DEFAULT_MAX_FILE_SIZE` |
| Enums | PascalCase | `ViewMode.Preview` |

---

### VI. Test-First Development {#P-TF}

Tests are written BEFORE implementation. This is non-negotiable.

#### TDD Workflow

1. Write test → 2. Verify test FAILS → 3. Implement → 4. Verify test PASSES → 5. Refactor

```typescript
// Write this FIRST (using Mocha + Sinon, per Technology Stack):
import * as sinon from 'sinon';
import { expect } from 'chai';
import * as vscode from 'vscode';

describe('PreviewService', () => {
  let executeCommandStub: sinon.SinonStub;

  beforeEach(() => {
    executeCommandStub = sinon.stub(vscode.commands, 'executeCommand');
  });

  afterEach(() => {
    sinon.restore();
  });

  it('should show preview when markdown file opens', async () => {
    const service = new PreviewService();
    const markdownUri = vscode.Uri.file('/test/sample.md');

    await service.showPreview(markdownUri);

    expect(executeCommandStub.calledWith('markdown.showPreview', markdownUri)).to.be.true;
  });
});

// THEN implement PreviewService.showPreview()
```

#### Coverage Requirements

- **Minimum 80%** code coverage required
- **100% coverage** for formatting operations (they modify user content)

#### Test Types

| Type | Purpose | Location |
|------|---------|----------|
| Unit tests | Test services in isolation | `tests/unit/` |
| Integration tests | Test VS Code API interactions | `tests/integration/` |
| Fixture files | Sample markdown for testing | `tests/fixtures/` |

#### Mocking Strategy

```typescript
// Mock VS Code APIs using Sinon (never use real file system in unit tests)
import * as sinon from 'sinon';

// Create stubs for VS Code APIs
const mockSecrets = {
  get: sinon.stub(),
  store: sinon.stub(),
  delete: sinon.stub()
};

const mockContext = {
  subscriptions: [],
  workspaceState: new MockMemento(),
  globalState: new MockMemento(),
  secrets: mockSecrets
} as unknown as vscode.ExtensionContext;

// Stub workspace.fs for file operations
const fsStatStub = sinon.stub(vscode.workspace.fs, 'stat');
fsStatStub.resolves({ size: 500 } as vscode.FileStat);

// Restore all stubs after each test
afterEach(() => sinon.restore());
```

---

### VII. Documentation Excellence {#P-DE}

Every public API must be documented. The codebase should teach.

#### JSDoc Requirements

Every public function must have:

```typescript
/**
 * Shows the markdown preview for the given document.
 *
 * Uses VS Code's native markdown preview command to render the document.
 * The preview opens in the current editor group, replacing the raw editor.
 *
 * @param uri - The URI of the markdown document to preview
 * @returns Promise that resolves when the preview is shown
 * @throws {Error} If the document is not a markdown file
 *
 * @example
 * ```typescript
 * await previewService.showPreview(document.uri);
 * ```
 */
async showPreview(uri: vscode.Uri): Promise<void>
```

#### README Requirements

The README must include:

- [ ] Clear installation instructions
- [ ] Feature overview with screenshots/GIFs
- [ ] Keyboard shortcuts table
- [ ] Configuration options table
- [ ] Known limitations
- [ ] Contributing guide link
- [ ] License

#### Code Comments

- **Explain "why"**, not "what"
- Complex algorithms need explanation
- Non-obvious VS Code API usage needs notes
- No commented-out code in production

---

### VIII. Beginner-Friendly Contribution Guidelines {#P-BF}

This project welcomes first-time contributors.

#### Documentation Requirements

Every public function/method must have JSDoc comments explaining:

- What it does (description)
- Parameters (`@param`)
- Return value (`@returns`)
- Exceptions (`@throws`)
- Usage example (`@example`) for non-obvious functions

#### Code Simplicity

- Prefer readable code over clever code
- Avoid complex nested ternaries
- Use early returns to reduce nesting
- Extract complex conditions into named boolean variables or functions
- Avoid abbreviations in variable names

#### Git Practices

- Conventional commits required
- One logical change per commit
- PR descriptions must explain what and why
- All PRs require at least one approval

#### Issue Labels for Beginners

| Label | Description |
|-------|-------------|
| `good-first-issue` | Simple, well-defined tasks |
| `help-wanted` | More complex but documented |
| `documentation` | Non-code contributions welcome |

---

### IX. Testing Requirements {#P-TR}

Comprehensive testing ensures reliability.

#### Coverage Requirements

- Minimum 80% code coverage required
- 100% coverage for formatting operations (they modify user content)

#### Test Types

- Unit tests for all services and utilities
- Integration tests for VS Code API interactions
- Manual test checklist for UI elements

#### Test Organization

- Test files mirror source structure
- One test file per source file
- Use descriptive test names: `should open markdown file in preview mode by default`

#### Mocking Strategy

- Mock VS Code APIs using `@vscode/test-electron`
- Create test fixtures for common markdown scenarios
- Never use real file system in unit tests

---

### X. VS Code Extension Best Practices {#P-VS}

#### Activation

Use lazy activation (`onLanguage:markdown` activation event) to minimize startup impact.

#### Disposables

Register ALL disposables with `context.subscriptions` to prevent memory leaks.

#### Settings Schema

Define settings in `package.json` with clear descriptions and defaults.

#### Telemetry

NO telemetry collection. User privacy is paramount.

#### Accessibility (WCAG 2.1 AA Target)

**MANDATORY**: All UI elements must be accessible.

**ARIA Labels Required On**:

| Element | Label Example |
|---------|---------------|
| Bold button | `"Bold (Ctrl+B)"` |
| Italic button | `"Italic (Ctrl+I)"` |
| Done button | `"Exit Edit Mode"` |
| Format menu | `"Format markdown"` |
| Status bar item | `"Markdown Reader: Preview Mode"` |

**Keyboard Navigation**:

| Key | Action | Context |
|-----|--------|---------|
| Tab | Move to next toolbar button | Edit mode toolbar |
| Enter/Space | Activate button | Any button focused |
| Escape | Return to editor | From toolbar |
| Ctrl+Shift+V | Toggle edit/preview mode | Any markdown context |

**Screen Reader Support**:

- All state changes MUST be announced
- Use `vscode.window.setStatusBarMessage()` for transient announcements
- Context keys trigger UI updates that screen readers detect

```typescript
// Example: Accessible command contribution
{
  "command": "markdownReader.formatBold",
  "title": "Bold",
  "icon": "$(bold)",
  "enablement": "markdownReader.editMode"
}

// Set accessible tooltip
button.tooltip = "Bold (Ctrl+B)";
button.accessibilityInformation = {
  label: "Apply bold formatting to selected text",
  role: "button"
};
```

#### Localization Ready

Use `vscode.l10n` for all user-facing strings (even if only English initially).

#### Command Namespace

**MANDATORY**: All commands MUST use the `markdownReader.` prefix to avoid collisions.

| Command ID | Purpose |
|------------|---------|
| `markdownReader.enterEditMode` | Switch from preview to edit mode |
| `markdownReader.exitEditMode` | Return to preview-only mode |
| `markdownReader.toggleEditMode` | Toggle between modes (Ctrl+Shift+V) |
| `markdownReader.formatBold` | Apply bold formatting |
| `markdownReader.formatItalic` | Apply italic formatting |
| `markdownReader.formatStrikethrough` | Apply strikethrough |
| `markdownReader.formatBulletList` | Toggle bullet list |
| `markdownReader.formatNumberedList` | Toggle numbered list |
| `markdownReader.formatCodeInline` | Apply inline code |
| `markdownReader.formatCodeBlock` | Apply code block |
| `markdownReader.formatLink` | Insert/wrap link |
| `markdownReader.formatHeading` | Apply heading (submenu) |

```json
// package.json contributes.commands example
{
  "commands": [
    {
      "command": "markdownReader.toggleEditMode",
      "title": "Toggle Edit Mode",
      "category": "Markdown Reader"
    }
  ]
}
```

#### UI Contributions

**Title Bar Buttons** (edit mode only):

Use `editor/title` contribution point with `when` clause:

```json
{
  "menus": {
    "editor/title": [
      {
        "command": "markdownReader.exitEditMode",
        "when": "markdownReader.editMode && resourceLangId == markdown",
        "group": "navigation"
      },
      {
        "command": "markdownReader.formatBold",
        "when": "markdownReader.editMode && resourceLangId == markdown",
        "group": "1_formatting"
      }
    ]
  }
}
```

**Context Menu** (Format submenu):

```json
{
  "menus": {
    "editor/context": [
      {
        "submenu": "markdownReader.format",
        "when": "markdownReader.editMode && resourceLangId == markdown",
        "group": "1_modification"
      }
    ]
  },
  "submenus": [
    {
      "id": "markdownReader.format",
      "label": "Format"
    }
  ]
}
```

**Heading Submenu** (nested under Format):

```json
{
  "menus": {
    "markdownReader.format": [
      {
        "submenu": "markdownReader.heading",
        "group": "2_structure"
      }
    ]
  },
  "submenus": [
    {
      "id": "markdownReader.heading",
      "label": "Heading"
    }
  ]
}
```

---

## Performance Standards

### Startup Impact

**MANDATORY: <50ms added to VS Code startup**

Use lazy activation:

```json
{
  "activationEvents": ["onLanguage:markdown"]
}
```

### Operation Performance

| Operation | Maximum Time |
|-----------|--------------|
| Open file → Preview shown | <1 second |
| Switch preview ↔ edit | <500ms |
| Format text operation | <100ms |
| Context key update | <50ms |

### Large File Handling

Files >1MB skip auto-preview to prevent lag:

```typescript
async function shouldShowPreview(document: TextDocument): Promise<boolean> {
  const stats = await workspace.fs.stat(document.uri);
  if (stats.size > config.maxFileSize) {
    showInfoMessage('File is large. Click to open preview.', 'Open Preview');
    return false;
  }
  return true;
}
```

---

## Prohibited Patterns

The following are explicitly forbidden:

| Pattern | Reason |
|---------|--------|
| `console.log` in production | Use VS Code's output channel |
| Custom webviews for markdown | Must use native preview |
| Auto-return to preview on save | Disruptive to workflow |
| Telemetry collection | User privacy |
| `any` types without justification | Type safety |
| Ignoring Promise rejections | Silent failures |
| Synchronous file operations | Performance impact |
| Modifying files without user action | Trust violation |

---

## Development Workflow

### Branch Strategy

| Branch | Purpose |
|--------|---------|
| `main` | Production-ready code only |
| `feature/*` or `feat/*` | New features |
| `fix/*` | Bug fixes |

### Commit Conventions

Conventional commits required:

- `feat:` - New features
- `fix:` - Bug fixes
- `docs:` - Documentation
- `refactor:` - Code changes without behavior change
- `test:` - Test additions/modifications
- `chore:` - Build, tooling, deps

### CI Pipeline

The CI pipeline must:

- [ ] TypeScript compilation with no errors
- [ ] ESLint with zero warnings
- [ ] All tests passing
- [ ] Coverage threshold met (80%)
- [ ] `npm audit` for security
- [ ] VSIX package builds successfully

### Pre-commit Hooks

- Format with Prettier
- Lint with ESLint
- Type-check with tsc

---

## Definition of Done

A feature is complete when:

- [ ] All acceptance criteria from spec are met
- [ ] Unit tests written and passing
- [ ] Integration tests written and passing
- [ ] Code coverage meets 80% threshold
- [ ] JSDoc comments on all public APIs
- [ ] No ESLint warnings
- [ ] No TypeScript errors in strict mode
- [ ] Manual testing completed
- [ ] Performance benchmarks met
- [ ] README updated if user-facing changes
- [ ] CHANGELOG updated

---

## Technology Stack

| Component | Technology |
|-----------|------------|
| Runtime | VS Code Extension Host (Node.js) |
| Language | TypeScript 5.x (strict mode) |
| Testing | Mocha + Sinon + Chai + @vscode/test-electron |
| Coverage | nyc (Istanbul) - minimum 80% |
| Linting | ESLint with TypeScript plugin |
| Formatting | Prettier |
| Bundling | esbuild |
| CI | GitHub Actions |

---

## Marketplace Requirements

**MANDATORY**: Extension must include all marketplace metadata for publication.

### package.json Required Fields

```json
{
  "name": "markdown-reader",
  "displayName": "Markdown Reader",
  "description": "Opens markdown files in preview mode by default for a clean reading experience",
  "version": "1.0.0",
  "publisher": "<your-publisher-id>",
  "license": "MIT",
  "icon": "images/icon.png",
  "repository": {
    "type": "git",
    "url": "https://github.com/<user>/markdown-reader"
  },
  "categories": ["Other"],
  "keywords": [
    "markdown",
    "preview",
    "reader",
    "documentation",
    "reading"
  ],
  "engines": {
    "vscode": "^1.85.0"
  }
}
```

### Required Assets

| Asset | Specification |
|-------|---------------|
| Icon | 128x128 PNG, transparent background |
| CHANGELOG.md | Semantic versioning, user-friendly format |
| README.md | Features, screenshots/GIFs, keyboard shortcuts |
| LICENSE | MIT license file |

### Icon Guidelines

- 128x128 pixels exactly
- PNG format with transparency
- Simple, recognizable design
- Works on light and dark backgrounds
- Placed in `images/icon.png`

---

## Reference Resources

- [VS Code Extension API](https://code.visualstudio.com/api)
- [Markdown Preview Extension Guide](https://code.visualstudio.com/api/extension-guides/markdown-preview)
- [VS Code Commands API](https://code.visualstudio.com/api/references/commands)
- [Extension Security Best Practices](https://code.visualstudio.com/api/extension-guides/security)
- [TypeScript Deep Dive](https://basarat.gitbook.io/typescript/)

---

## Principle Reference Index

Stable identifiers for cross-referencing in plans and validation gates.

| ID | Principle | Key Validation |
|----|-----------|----------------|
| P-RF | Reading-First Experience | Uses `markdown.showPreview`; zero UI in preview mode |
| P-NI | Native Integration | No custom webviews; no custom parsers |
| P-ZC | Zero-Configuration | Works immediately; sensible defaults |
| P-ND | Non-Intrusive Design | No auto-return on save; respects user intent |
| P-PQ | Production-Quality Code | TS strict; no `any`; kebab-case files |
| P-TF | Test-First Development | Tests before implementation; 80% coverage |
| P-DE | Documentation Excellence | JSDoc on public APIs; README complete |
| P-BF | Beginner-Friendly | Clear docs; simple code; good-first-issues |
| P-TR | Testing Requirements | Unit + integration tests; mocked VS Code APIs |
| P-VS | VS Code Best Practices | Lazy activation; disposables registered; ARIA labels |

---

## SpecKit Integration

### How This Constitution is Used

1. **Plan Validation** (`/speckit.plan`): Plans MUST pass Constitution Check against principles P-RF through P-VS before research phase
2. **Task Generation** (`/speckit.tasks`): Task categories and validation gates derive from principles
3. **Implementation** (`/speckit.implement`): Code MUST satisfy principles at each checkpoint; checklists verify compliance
4. **Constitution Updates** (`/speckit.constitution`): Version changes propagate to dependent templates

### Cross-References

| Template | Validates Against |
|----------|-------------------|
| `plan-template.md` | Constitution Check section validates P-RF, P-NI, P-ZC, P-ND, P-PQ, P-TF, P-DE |
| `spec-template.md` | Success Criteria align with NFR requirements from principles |
| `tasks-template.md` | Task categories match principle-driven phases |
| `checklist-template.md` | Items map to Definition of Done criteria |

### Memory Loading

- Constitution is loaded via `@.specify/memory/constitution.md` import in CLAUDE.md
- Principles are available in context for all SpecKit commands
- Plan.md Constitution Check references principles by ID (e.g., "Principle I (Reading-First): ✅")

---

## Violation Recovery

If a constitution violation is detected during implementation:

1. **STOP** current task immediately
2. **REPORT** the violation with principle reference (e.g., "Violates P-NI: created custom webview")
3. **REVERT** any violating changes if already committed
4. **PROPOSE** compliant alternative approach
5. **WAIT** for user confirmation before proceeding
6. **DOCUMENT** the violation and resolution in commit message

**IMPORTANT**: Do NOT attempt to "fix it later" or continue with violations. Constitution compliance is a gate, not a suggestion.

### Common Violation Scenarios

| Violation | Principle | Recovery Action |
|-----------|-----------|-----------------|
| Created custom webview | P-NI | Delete webview; use `markdown.showPreview` |
| Skipped tests | P-TF | Stop; write failing tests first |
| Used `any` type | P-PQ | Replace with proper type or `unknown` + type guard |
| Added telemetry | P-VS | Remove immediately; no data collection allowed |
| Auto-return on save | P-ND | Remove save handler; keep user in edit mode |

---

## AI Agent Anti-Patterns

When implementing this project, Claude MUST NOT fall into these traps:

### Over-Engineering

❌ **DON'T** create utility functions until used at least twice:
```typescript
// ❌ BAD: Premature abstraction for single use
function wrapWithMarkers(text: string, marker: string): string {
  return `${marker}${text}${marker}`;
}
const bold = wrapWithMarkers(selection, '**');

// ✅ GOOD: Inline for single use
const bold = `**${selection}**`;
```

❌ **DON'T** add caching without measured performance need
❌ **DON'T** create abstractions for single-use operations
❌ **DON'T** add configuration options for edge cases

### Defensive Over-Coding

❌ **DON'T** add error handling for impossible states:
```typescript
// ❌ BAD: Impossible state check
function getFileState(uri: string): FileState {
  const state = this.stateMap.get(uri);
  if (!state) {
    // This can't happen if we control all callers
    throw new Error('State not found');
  }
  return state;
}

// ✅ GOOD: Trust internal code
function getFileState(uri: string): FileState | undefined {
  return this.stateMap.get(uri);
}
```

❌ **DON'T** validate internal function inputs (trust internal code)
❌ **DON'T** add fallbacks for scenarios that can't happen
❌ **DON'T** wrap every operation in try-catch

### Documentation Sprawl

❌ **DON'T** add comments explaining obvious code:
```typescript
// ❌ BAD: Obvious comment
// Increment the counter
counter++;

// ✅ GOOD: No comment needed for obvious code
counter++;

// ✅ GOOD: Comment explains WHY, not WHAT
// VS Code requires closing editor before opening preview to avoid flicker
await commands.executeCommand('workbench.action.closeActiveEditor');
```

❌ **DON'T** add TypeScript types to unchanged code
❌ **DON'T** create README sections for unimplemented features
❌ **DON'T** add JSDoc to private functions

### Scope Creep

❌ **DON'T** refactor surrounding code when fixing bugs:
```typescript
// ❌ BAD: Bug fix + unrequested refactor
// Task: Fix the null check
// But also renamed variables, extracted function, added types...

// ✅ GOOD: Minimal fix only
if (document?.uri) { // Fixed: added null check
  await showPreview(document.uri);
}
```

❌ **DON'T** add "nice to have" features not in spec
❌ **DON'T** improve code style in files you're not modifying
❌ **DON'T** add backwards-compatibility shims preemptively

### Common Mistakes Table

| Mistake | Why It's Wrong | Correct Approach |
|---------|----------------|------------------|
| `const data: any = ...` | Loses type safety | Use `unknown` + type guard |
| `console.log(debug)` | Not for production | Use VS Code OutputChannel |
| `fs.readFileSync()` | Blocks extension host | Use `workspace.fs.readFile()` |
| Custom markdown renderer | Violates P-NI | Use `markdown.showPreview` |
| `try { } catch { }` everywhere | Hides real errors | Catch only expected errors |
| Adding 10 config options | Over-engineering | Start with sensible defaults |

**When in doubt, choose the simpler implementation.**

---

## Governance

This constitution supersedes all other development practices. Amendments require:

1. Written proposal with rationale
2. Review of impact on existing code
3. Migration plan for breaking changes
4. Update to this document
5. Version increment via `/speckit.constitution`

All code reviews must verify compliance with these principles.

### Conflict Resolution

When instructions conflict:
1. This constitution takes precedence over ad-hoc suggestions
2. Explicit user instructions override constitution (with documented justification)
3. When uncertain, ask before proceeding
4. Log decisions in commit messages

---

## Metadata

```yaml
constitution_version: 1.3.0
ratified: 2025-12-23
last_amended: 2025-12-25
speckit_compatible: true
principles_count: 10
ai_optimizations:
  - priority_hierarchy
  - extended_thinking_triggers
  - self_check_questions
  - negative_examples_with_code
  - conditional_loading_frontmatter
spec_alignment:
  - command_namespace_guidance
  - ui_contribution_patterns
  - edge_case_coverage
  - accessibility_wcag_details
  - marketplace_requirements
  - mocha_sinon_test_examples
  - terminology_consistency
validation_gates:
  plan_phase: [P-RF, P-NI, P-ZC, P-ND, P-PQ]
  implementation_phase: [P-TF, P-DE, P-TR]
  completion_phase: [all]
```

**Version**: 1.3.0 | **Ratified**: 2025-12-23 | **Last Amended**: 2025-12-25
