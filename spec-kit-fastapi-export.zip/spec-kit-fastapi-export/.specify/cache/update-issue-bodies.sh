#!/bin/bash
# Script to update GitHub issue bodies with milestone gate context and phase renumbering

# Gate context templates
SPRINT_0_GATE='

## Milestone Gate Context

This task is part of **Sprint 0** (industry standard pre-development phase per [BMC Software](https://www.bmc.com/blogs/sprint-zero/)).

**Gate Requirement**: Sprint 0 complete when CI is green ✅

**Blocking**: Phase 1 (Foundational) is BLOCKED until this milestone gate passes.

**Reference**: See [docs/ROADMAP.md](../../docs/ROADMAP.md) line 31 for gate requirements.'

PHASE1_GATE='

## Milestone Gate Context

This task is part of **Phase 1: Foundational** (blocking prerequisite for all user stories).

**Gate Requirement**: Full test suite must pass before Phase 2 can begin.

**Dependency**: Sprint 0 must be complete (CI green).

**Blocking**: All user story implementation (Phase 2-7) is BLOCKED until this phase completes.'

US_GATE_TEMPLATE='

## Milestone Gate Context

This task is part of **PHASE_NAME**.

**Gate Requirement**: Full test suite must pass before next phase can begin.

**Dependency**: Previous phases must be complete.'

# Function to update a single issue
update_issue() {
  task_id=$1
  task_num=${task_id#T}
  task_num=$((10#$task_num))  # Convert to number

  # Get issue number
  issue_number=$(gh issue list --search "[$task_id]" --json number --jq '.[0].number')

  if [ -z "$issue_number" ]; then
    echo "⚠ No issue found for $task_id"
    return
  fi

  # Get current issue data
  issue_data=$(gh issue view "$issue_number" --json title,body)
  current_title=$(echo "$issue_data" | jq -r '.title')
  current_body=$(echo "$issue_data" | jq -r '.body')

  # Determine phase and gate context
  gate_context=""
  if [ $task_num -ge 1 ] && [ $task_num -le 11 ]; then
    phase="Sprint 0"
    gate_context="$SPRINT_0_GATE"
  elif [ $task_num -ge 12 ] && [ $task_num -le 22 ] || [ "$task_id" == "T125" ] || [ "$task_id" == "T126" ] || [ "$task_id" == "T139" ]; then
    phase="Phase 1"
    gate_context="$PHASE1_GATE"
  elif [ $task_num -ge 23 ] && [ $task_num -le 46 ]; then
    phase="Phase 2"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 2: US1 (Preview by Default)}"
  elif [ $task_num -ge 47 ] && [ $task_num -le 52 ]; then
    phase="Phase 3"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 3: US2 (Edit Mode)}"
  elif [ $task_num -ge 53 ] && [ $task_num -le 71 ]; then
    phase="Phase 4"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 4: US3 (Formatting Toolbar)}"
  elif [ $task_num -ge 72 ] && [ $task_num -le 81 ]; then
    phase="Phase 5"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 5: US4 (Context Menu)}"
  elif [ $task_num -ge 82 ] && [ $task_num -le 90 ]; then
    phase="Phase 6"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 6: US5 (Keyboard Shortcuts)}"
  elif [ $task_num -ge 91 ] && [ $task_num -le 103 ]; then
    phase="Phase 7"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 7: US6 (Configuration)}"
  elif [ $task_num -ge 104 ] && [ $task_num -le 109 ] || [ "$task_id" == "T136" ]; then
    phase="Phase 8"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 8: Testing & Quality}"
  else
    phase="Phase 9"
    gate_context="${US_GATE_TEMPLATE//PHASE_NAME/Phase 9: Polish & Documentation}"
  fi

  # Update body with phase references (reverse order to avoid conflicts)
  new_body="$current_body"
  new_body=$(echo "$new_body" | sed \
    -e 's/Phase 10:/Phase 9:/g' \
    -e 's/Phase 9:/Phase 8:/g' \
    -e 's/Phase 8:/Phase 7:/g' \
    -e 's/Phase 7:/Phase 6:/g' \
    -e 's/Phase 6:/Phase 5:/g' \
    -e 's/Phase 5:/Phase 4:/g' \
    -e 's/Phase 4:/Phase 3:/g' \
    -e 's/Phase 3:/Phase 2:/g' \
    -e 's/Phase 2:/Phase 1:/g' \
    -e 's/Phase 1: Setup/Sprint 0: Test Infrastructure/g')

  # Add gate context if not already present
  if ! echo "$new_body" | grep -q "Milestone Gate Context"; then
    new_body="${new_body}${gate_context}"
  fi

  # Update title with phase references
  new_title=$(echo "$current_title" | sed \
    -e 's/Phase 10:/Phase 9:/g' \
    -e 's/Phase 9:/Phase 8:/g' \
    -e 's/Phase 8:/Phase 7:/g' \
    -e 's/Phase 7:/Phase 6:/g' \
    -e 's/Phase 6:/Phase 5:/g' \
    -e 's/Phase 5:/Phase 4:/g' \
    -e 's/Phase 4:/Phase 3:/g' \
    -e 's/Phase 3:/Phase 2:/g' \
    -e 's/Phase 2:/Phase 1:/g' \
    -e 's/Phase 1: Setup/Sprint 0: Test Infrastructure/g')

  # Update the issue if changes were made
  if [ "$new_title" != "$current_title" ] || [ "$new_body" != "$current_body" ]; then
    # Escape special characters for jq
    escaped_body=$(echo "$new_body" | jq -Rs .)
    escaped_title=$(echo "$new_title" | jq -Rs .)

    gh issue edit "$issue_number" \
      --title "$(echo "$escaped_title" | jq -r .)" \
      --body "$(echo "$escaped_body" | jq -r .)"

    if [ $? -eq 0 ]; then
      echo "✓ Updated $task_id (#$issue_number) - $phase"
    else
      echo "✗ Failed to update $task_id (#$issue_number)"
    fi

    sleep 0.5  # Rate limiting protection
  else
    echo "- No changes needed for $task_id (#$issue_number)"
  fi
}

echo "Updating issue bodies with milestone gates and phase renumbering..."
echo ""

# Process all tasks
for i in $(seq -f "T%03g" 1 139); do
  update_issue "$i"
done

# Process special tasks
update_issue "T125"
update_issue "T126"
update_issue "T135"
update_issue "T136"
update_issue "T137"
update_issue "T139"

echo ""
echo "✅ Issue body updates complete!"
