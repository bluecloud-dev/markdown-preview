#!/bin/bash
# Script to apply phase labels to all GitHub issues

# Function to add label to a task
add_phase_label() {
  task_id=$1
  label=$2

  issue_number=$(gh issue list --search "[$task_id]" --json number --jq '.[0].number')

  if [ -n "$issue_number" ]; then
    gh issue edit "$issue_number" --add-label "$label" 2>&1
    if [ $? -eq 0 ]; then
      echo "✓ Added $label to $task_id (#$issue_number)"
    else
      echo "✗ Failed to add $label to $task_id (#$issue_number)"
    fi
    sleep 0.3  # Rate limiting protection
  else
    echo "⚠ No issue found for $task_id"
  fi
}

echo "Applying phase labels to all issues..."
echo ""

# Sprint 0 (T001-T011)
echo "Sprint 0 tasks (T001-T011)..."
for i in $(seq -f "T%03g" 1 11); do
  add_phase_label "$i" "phase:sprint-0"
done

# Phase 1: Foundational (T012-T022, T125-T126, T139)
echo ""
echo "Phase 1: Foundational tasks (T012-T022, T125-T126, T139)..."
for i in $(seq -f "T%03g" 12 22); do
  add_phase_label "$i" "phase:foundational"
done
add_phase_label "T125" "phase:foundational"
add_phase_label "T126" "phase:foundational"
add_phase_label "T139" "phase:foundational"

# Phase 2: US1 (T023-T046)
echo ""
echo "Phase 2: US1 tasks (T023-T046)..."
for i in $(seq -f "T%03g" 23 46); do
  add_phase_label "$i" "phase:us1-preview"
done

# Phase 3: US2 (T047-T052)
echo ""
echo "Phase 3: US2 tasks (T047-T052)..."
for i in $(seq -f "T%03g" 47 52); do
  add_phase_label "$i" "phase:us2-edit"
done

# Phase 4: US3 (T053-T071)
echo ""
echo "Phase 4: US3 tasks (T053-T071)..."
for i in $(seq -f "T%03g" 53 71); do
  add_phase_label "$i" "phase:us3-toolbar"
done

# Phase 5: US4 (T072-T081)
echo ""
echo "Phase 5: US4 tasks (T072-T081)..."
for i in $(seq -f "T%03g" 72 81); do
  add_phase_label "$i" "phase:us4-context"
done

# Phase 6: US5 (T082-T090)
echo ""
echo "Phase 6: US5 tasks (T082-T090)..."
for i in $(seq -f "T%03g" 82 90); do
  add_phase_label "$i" "phase:us5-shortcuts"
done

# Phase 7: US6 (T091-T103)
echo ""
echo "Phase 7: US6 tasks (T091-T103)..."
for i in $(seq -f "T%03g" 91 103); do
  add_phase_label "$i" "phase:us6-config"
done

# Phase 8: Testing (T104-T109, T136)
echo ""
echo "Phase 8: Testing tasks (T104-T109, T136)..."
for i in $(seq -f "T%03g" 104 109); do
  add_phase_label "$i" "phase:testing"
done
add_phase_label "T136" "phase:testing"

# Phase 9: Polish (T110-T124, T135, T137)
echo ""
echo "Phase 9: Polish tasks (T110-T124, T135, T137)..."
for i in $(seq -f "T%03g" 110 124); do
  add_phase_label "$i" "phase:polish"
done
add_phase_label "T135" "phase:polish"
add_phase_label "T137" "phase:polish"

echo ""
echo "✅ Phase label application complete!"
