---

description: "Task list template for feature implementation"
---

# Tasks: [FEATURE NAME]

**Input**: Design documents from `/specs/<feature-slug>/`
**Prerequisites**: plan.md (required), spec.md (required for user stories), research.md, data-model.md, contracts/

**Tests**: The examples below include test tasks. Tests are OPTIONAL - only include them if explicitly requested in the feature specification.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Single project**: `src/`, `tests/` at repository root
- **Web app**: `backend/src/`, `frontend/src/`
- **Mobile**: `api/src/`, `ios/src/` or `android/src/`
- Paths shown below assume single project - adjust based on plan.md structure

<!-- 
  ============================================================================
  IMPORTANT: The tasks below are SAMPLE TASKS for illustration purposes only.
  
  The /speckit.tasks command MUST replace these with actual tasks based on:
  - User stories from spec.md (with their priorities P1, P2, P3...)
  - Feature requirements from plan.md
  - Entities from data-model.md
  - Endpoints from contracts/
  
  Tasks MUST be organized by user story so each story can be:
  - Implemented independently
  - Tested independently
  - Delivered as an MVP increment
  
  DO NOT keep these sample tasks in the generated tasks.md file.
  ============================================================================
-->

## Sprint 0: Test Infrastructure + Walking Skeleton

**Purpose**: Establish test infrastructure and prove the stack works BEFORE any feature implementation.

**Industry Standard**: [Sprint 0](https://www.bmc.com/blogs/sprint-zero/) / [Iteration 0](https://kingsinsight.com/2011/09/30/sprint-0-or-iteration-0-checklist-simple-but-not-always-easy/) - the pre-development phase for infrastructure setup.

**⚠️ CRITICAL**: Sprint 0 MUST be complete and CI green before ANY feature work begins.

### Test Scaffolding

- [ ] T001 Create test directories (`tests/unit/`, `tests/integration/`, `tests/fixtures/`)
- [ ] T002 Install test framework dependencies (verify latest stable versions online)
- [ ] T003 Configure test runner and coverage tool (80% gate, 100% for critical ops)
- [ ] T004 Create sample test fixture files

### CI/CD Pipeline

- [ ] T005 [P] Create `.github/workflows/ci.yml` with lint, test, coverage gates
- [ ] T006 [P] Configure GitHub Actions to run on push and PR
- [ ] T007 [P] Add coverage badge to README (optional)

**GitHub Actions CI Template** (adjust for your stack):

```yaml
# .github/workflows/ci.yml
name: CI
on:
  push:
    branches: [main, 'spec/**', 'feature/**']
  pull_request:
    branches: [main, 'spec/**']

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Lint
        run: npm run lint

      - name: Test
        run: npm test

      - name: Coverage
        run: npm run coverage
        # Fail if coverage below threshold
        # Configure in nyc/jest config

      - name: Build
        run: npm run compile
```

### Walking Skeleton

- [ ] T008 Create minimal entry point that proves stack works (e.g., extension activates)
- [ ] T009 Create first passing test (proves test infrastructure works)
- [ ] T010 Verify CI is green with walking skeleton

**✅ Sprint 0 Complete When**: CI is green, walking skeleton activates, at least one test passes.

---

## Phase 1: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

Examples of foundational tasks (adjust based on your project):

- [ ] T011 Setup database schema and migrations framework
- [ ] T012 [P] Implement authentication/authorization framework
- [ ] T013 [P] Setup API routing and middleware structure
- [ ] T014 Create base models/entities that all stories depend on
- [ ] T015 Configure error handling and logging infrastructure
- [ ] T016 Setup environment configuration management

**Checkpoint**: Foundation ready - user story implementation can now begin in parallel

**🧪 Milestone Gate**: Run full test suite. BLOCK Phase 2 if any tests fail.

---

## Phase 2: User Story 1 - [Title] (Priority: P1) 🎯 MVP

**Goal**: [Brief description of what this story delivers]

**Independent Test**: [How to verify this story works on its own]

### Tests for User Story 1 (OPTIONAL - only if tests requested) ⚠️

> **NOTE: Write these tests FIRST, ensure they FAIL before implementation**

- [ ] T017 [P] [US1] Contract test for [endpoint] in tests/contract/test_[name].py
- [ ] T018 [P] [US1] Integration test for [user journey] in tests/integration/test_[name].py

### Implementation for User Story 1

- [ ] T019 [P] [US1] Create [Entity1] model in src/models/[entity1].py
- [ ] T020 [P] [US1] Create [Entity2] model in src/models/[entity2].py
- [ ] T021 [US1] Implement [Service] in src/services/[service].py (depends on T019, T020)
- [ ] T022 [US1] Implement [endpoint/feature] in src/[location]/[file].py
- [ ] T023 [US1] Add validation and error handling
- [ ] T024 [US1] Add logging for user story 1 operations

**Checkpoint**: At this point, User Story 1 should be fully functional and testable independently

**🧪 Milestone Gate**: Run full test suite. BLOCK Phase 3 if any tests fail.

---

## Phase 3: User Story 2 - [Title] (Priority: P2)

**Goal**: [Brief description of what this story delivers]

**Independent Test**: [How to verify this story works on its own]

### Tests for User Story 2 (OPTIONAL - only if tests requested) ⚠️

- [ ] T025 [P] [US2] Contract test for [endpoint] in tests/contract/test_[name].py
- [ ] T026 [P] [US2] Integration test for [user journey] in tests/integration/test_[name].py

### Implementation for User Story 2

- [ ] T027 [P] [US2] Create [Entity] model in src/models/[entity].py
- [ ] T028 [US2] Implement [Service] in src/services/[service].py
- [ ] T029 [US2] Implement [endpoint/feature] in src/[location]/[file].py
- [ ] T030 [US2] Integrate with User Story 1 components (if needed)

**Checkpoint**: At this point, User Stories 1 AND 2 should both work independently

**🧪 Milestone Gate**: Run full test suite. BLOCK Phase 4 if any tests fail.

---

## Phase 4: User Story 3 - [Title] (Priority: P3)

**Goal**: [Brief description of what this story delivers]

**Independent Test**: [How to verify this story works on its own]

### Tests for User Story 3 (OPTIONAL - only if tests requested) ⚠️

- [ ] T031 [P] [US3] Contract test for [endpoint] in tests/contract/test_[name].py
- [ ] T032 [P] [US3] Integration test for [user journey] in tests/integration/test_[name].py

### Implementation for User Story 3

- [ ] T033 [P] [US3] Create [Entity] model in src/models/[entity].py
- [ ] T034 [US3] Implement [Service] in src/services/[service].py
- [ ] T035 [US3] Implement [endpoint/feature] in src/[location]/[file].py

**Checkpoint**: All user stories should now be independently functional

**🧪 Milestone Gate**: Run full test suite. BLOCK Polish phase if any tests fail.

---

[Add more user story phases as needed, following the same pattern]

---

## Phase N: Polish & Cross-Cutting Concerns

**Purpose**: Improvements that affect multiple user stories

- [ ] TXXX [P] Documentation updates in docs/
- [ ] TXXX Code cleanup and refactoring
- [ ] TXXX Performance optimization across all stories
- [ ] TXXX [P] Additional unit tests (if requested) in tests/unit/
- [ ] TXXX Security hardening
- [ ] TXXX Run quickstart.md validation

**🧪 Final Milestone Gate**: Run FULL test suite with coverage. Release BLOCKED if:
- Any test fails
- Coverage < 80% (or project threshold)
- Lint errors present

---

## Dependencies & Execution Order

### Phase Dependencies

- **Sprint 0 (Test Infra + Walking Skeleton)**: No dependencies - ALWAYS FIRST
  - **GATE**: CI must be green before Phase 1 begins
- **Foundational (Phase 1)**: Depends on Sprint 0 completion - BLOCKS all user stories
  - **GATE**: Full test suite must pass before Phase 2 begins
- **User Stories (Phase 2+)**: All depend on Foundational phase completion
  - User stories can then proceed in parallel (if staffed)
  - Or sequentially in priority order (P1 → P2 → P3)
  - **GATE**: Each phase ends with full test suite; next phase BLOCKED if tests fail
- **Polish (Final Phase)**: Depends on all desired user stories being complete
  - **GATE**: Release BLOCKED until all tests pass and coverage meets threshold

### User Story Dependencies

- **User Story 1 (P1)**: Can start after Foundational (Phase 1) - No dependencies on other stories
- **User Story 2 (P2)**: Can start after Foundational (Phase 1) - May integrate with US1 but should be independently testable
- **User Story 3 (P3)**: Can start after Foundational (Phase 1) - May integrate with US1/US2 but should be independently testable

### Within Each User Story

- Tests (if included) MUST be written and FAIL before implementation
- Models before services
- Services before endpoints
- Core implementation before integration
- Story complete before moving to next priority

### Parallel Opportunities

- All Sprint 0 tasks marked [P] can run in parallel (CI setup, linting, etc.)
- All Foundational tasks marked [P] can run in parallel (within Phase 1)
- Once Foundational phase completes AND tests pass, all user stories can start in parallel (if team capacity allows)
- All tests for a user story marked [P] can run in parallel
- Models within a story marked [P] can run in parallel
- Different user stories can be worked on in parallel by different team members

---

## Parallel Example: User Story 1

```bash
# Launch all tests for User Story 1 together (if tests requested):
Task: "Contract test for [endpoint] in tests/contract/test_[name].py"
Task: "Integration test for [user journey] in tests/integration/test_[name].py"

# Launch all models for User Story 1 together:
Task: "Create [Entity1] model in src/models/[entity1].py"
Task: "Create [Entity2] model in src/models/[entity2].py"
```

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Sprint 0: Test Infra + Walking Skeleton → **CI must be green**
2. Complete Phase 1: Foundational (CRITICAL - blocks all stories) → **Tests must pass**
3. Complete Phase 2: User Story 1 → **Tests must pass**
4. **STOP and VALIDATE**: Test User Story 1 independently
5. Deploy/demo if ready

### Incremental Delivery (Milestone-Driven)

1. Complete Sprint 0 → CI green, walking skeleton works
2. Complete Foundational → **Milestone Gate: all tests pass before proceeding**
3. Add User Story 1 → Test independently → **Milestone Gate: all tests pass** → Deploy/Demo (MVP!)
4. Add User Story 2 → Test independently → **Milestone Gate: all tests pass** → Deploy/Demo
5. Add User Story 3 → Test independently → **Milestone Gate: all tests pass** → Deploy/Demo
6. Each story adds value without breaking previous stories
7. **BLOCKED if any milestone gate fails** - fix before proceeding

### Parallel Team Strategy

With multiple developers:

1. Team completes Sprint 0 + Foundational together (gates must pass)
2. Once Foundational is done AND tests pass:
   - Developer A: User Story 1
   - Developer B: User Story 2
   - Developer C: User Story 3
3. Stories complete and integrate independently
4. Each developer runs full test suite before merging

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Verify tests fail before implementing
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence

## Milestone Test Gates

**⚠️ CRITICAL**: Each milestone MUST pass the test gate before proceeding:

| Milestone | Gate Requirement |
|-----------|------------------|
| Sprint 0 Complete | CI green, walking skeleton test passes |
| Phase 1 Complete | Full test suite passes |
| Each User Story Complete | Full test suite passes |
| Release | All tests pass, coverage ≥80%, no lint errors |

**If gate fails**: FIX before proceeding. Do not skip gates.

## Dependency Version Policy

Before starting Sprint 0, verify all dependencies are at **latest stable versions**:

1. Search online (npm, pypi, etc.) for latest stable version
2. Update `package.json` / `requirements.txt` / etc.
3. Run tests to verify compatibility
4. Document version choices in `plan.md` or `README.md`
