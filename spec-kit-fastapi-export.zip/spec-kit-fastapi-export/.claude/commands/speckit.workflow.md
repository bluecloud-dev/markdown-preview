---
name: speckit.workflow
description: Defines the SpecKit branching strategy and Git workflow. Spec branches contain all design artifacts; task branches implement individual tasks with PRs back to spec branch; milestone completion triggers PR to main with tag and release.
---

# SpecKit Git Workflow

Structured branching strategy for specification-driven development.

## Branch Hierarchy

```
main (protected)
├── spec/{feature-name}           # Specification branch (long-lived)
│   ├── specs/{feature}/spec.md   # Feature specification
│   ├── specs/{feature}/plan.md   # Implementation plan
│   ├── specs/{feature}/tasks.md  # Task breakdown
│   └── ... other spec artifacts
│
└── task/{feature}/{task-id}      # Task implementation branches (short-lived)
    └── src/...                   # Implementation code
```

## Branch Naming Conventions

| Branch Type | Pattern | Example |
|-------------|---------|---------|
| Main | `main` | `main` |
| Spec | `spec/{feature-kebab-case}` | `spec/markdown-preview` |
| Task | `task/{feature}/{task-id}-{short-desc}` | `task/markdown-preview/T001-test-scaffolding` |
| Hotfix | `hotfix/{issue-id}-{desc}` | `hotfix/42-fix-preview-crash` |

## Workflow Phases

### Phase 1: Specification (on spec branch)

```mermaid
gitGraph
    commit id: "main"
    branch spec/feature-name
    checkout spec/feature-name
    commit id: "spec.md"
    commit id: "plan.md"
    commit id: "tasks.md"
```

**Commands**:
- `/speckit.specify` → Creates `spec/{feature}` branch, adds `spec.md`
- `/speckit.plan` → Adds `plan.md` on spec branch
- `/speckit.tasks` → Adds `tasks.md` on spec branch
- `/speckit.issues` → Creates GitHub issues from tasks (no branch change)

**Git Operations**:
```bash
# Create spec branch from main
git checkout main
git pull origin main
git checkout -b spec/{feature-name}

# After each spec command, commit
git add specs/{feature}/
git commit -m "docs({feature}): add specification"
git push -u origin spec/{feature-name}
```

### Phase 2: Implementation (task branches)

```mermaid
gitGraph
    commit id: "main"
    branch spec/feature
    commit id: "spec.md"
    commit id: "plan.md"
    commit id: "tasks.md"
    branch task/feature/T001
    commit id: "T001 impl"
    checkout spec/feature
    merge task/feature/T001 id: "PR #1"
    branch task/feature/T002
    commit id: "T002 impl"
    checkout spec/feature
    merge task/feature/T002 id: "PR #2"
```

**For each task**:

1. **Create task branch** from spec branch:
   ```bash
   git checkout spec/{feature}
   git pull origin spec/{feature}
   git checkout -b task/{feature}/T{id}-{short-desc}
   ```

2. **Implement the task**:
   - Write failing test (TDD)
   - Implement code
   - Verify tests pass
   - Commit with conventional commit message

3. **Create PR to spec branch**:
   ```bash
   git push -u origin task/{feature}/T{id}-{short-desc}

   gh pr create \
     --base spec/{feature} \
     --title "[T{id}] {Task description}" \
     --body "$(cat <<'EOF'
   ## Summary

   Implements task T{id} from tasks.md.

   Fixes #{issue-number}

   ## Changes

   - {change 1}
   - {change 2}

   ## Test Plan

   - [ ] Unit tests pass
   - [ ] Integration tests pass
   - [ ] Manual verification

   ---
   🤖 Generated with [Claude Code](https://claude.com/claude-code)
   EOF
   )"
   ```

4. **After merge**, delete task branch:
   ```bash
   git checkout spec/{feature}
   git pull origin spec/{feature}
   git branch -d task/{feature}/T{id}-{short-desc}
   ```

### Phase 3: Milestone Release (PR to main)

```mermaid
gitGraph
    commit id: "main"
    branch spec/feature
    commit id: "spec + tasks"
    commit id: "T001-T010 merged"
    commit id: "T011-T052 merged"
    checkout main
    merge spec/feature id: "v0.1.0 PR" tag: "v0.1.0"
```

**At milestone completion**:

1. **Verify all milestone tasks complete**:
   ```bash
   # Check all milestone issues are closed
   gh issue list --milestone "v0.1.0" --state open
   # Should return empty
   ```

2. **Update version and changelog**:
   ```bash
   git checkout spec/{feature}
   # Update package.json version
   # Update CHANGELOG.md
   git add package.json CHANGELOG.md
   git commit -m "chore: bump version to v0.1.0"
   git push
   ```

3. **Create PR to main**:
   ```bash
   gh pr create \
     --base main \
     --head spec/{feature} \
     --title "Release v0.1.0 - {Milestone Theme}" \
     --body "$(cat <<'EOF'
   ## Release v0.1.0 - {Milestone Theme}

   ### Summary

   {Brief description of what this milestone delivers}

   ### Features

   - {Feature 1}
   - {Feature 2}

   ### Issues Closed

   {Auto-generated from milestone}

   ### Breaking Changes

   None

   ### Migration Guide

   N/A (initial release)

   ---

   **Milestone**: https://github.com/{owner}/{repo}/milestone/{n}
   **Full Changelog**: https://github.com/{owner}/{repo}/compare/v0.0.0...v0.1.0
   EOF
   )"
   ```

4. **After PR merge, tag and release**:
   ```bash
   git checkout main
   git pull origin main

   # Create annotated tag
   git tag -a v0.1.0 -m "Release v0.1.0 - {Milestone Theme}"
   git push origin v0.1.0

   # Create GitHub release
   gh release create v0.1.0 \
     --title "v0.1.0 - {Milestone Theme}" \
     --notes "$(cat <<'EOF'
   ## What's New

   {Release notes from CHANGELOG.md}

   ## Installation

   ```bash
   # From marketplace
   code --install-extension {publisher}.{extension}

   # From VSIX
   code --install-extension {extension}-0.1.0.vsix
   ```

   ## Full Changelog

   See [CHANGELOG.md](CHANGELOG.md)
   EOF
   )" \
     --attach dist/{extension}-0.1.0.vsix
   ```

5. **Close milestone**:
   ```bash
   gh api repos/{owner}/{repo}/milestones/{milestone_number} \
     -X PATCH -f state="closed"
   ```

## Workflow Integration with SpecKit Commands

### `/speckit.specify`

**Before** (current behavior):
- Creates spec.md in current branch

**After** (new behavior):
```bash
# 1. Ensure on main and up-to-date
git checkout main
git pull origin main

# 2. Create spec branch
git checkout -b spec/{feature-name}

# 3. Create spec.md
mkdir -p specs/{feature-name}
# ... generate spec.md ...

# 4. Commit and push
git add specs/{feature-name}/spec.md
git commit -m "docs({feature}): add feature specification"
git push -u origin spec/{feature-name}
```

### `/speckit.plan`

**Before**: Creates plan.md in current branch

**After**:
```bash
# 1. Ensure on spec branch
current_branch=$(git branch --show-current)
if [[ ! "$current_branch" =~ ^spec/ ]]; then
  echo "Error: Must be on spec branch. Run /speckit.specify first."
  exit 1
fi

# 2. Create plan.md
# ... generate plan.md ...

# 3. Commit and push
git add specs/{feature}/plan.md
git commit -m "docs({feature}): add implementation plan"
git push
```

### `/speckit.tasks`

**Before**: Creates tasks.md in current branch

**After**:
```bash
# 1. Verify on spec branch
# 2. Create tasks.md
# 3. Commit and push
git add specs/{feature}/tasks.md
git commit -m "docs({feature}): add implementation tasks"
git push
```

### `/speckit.issues`

Works on any branch (creates GitHub resources, no file changes required).

### `/speckit.implement`

**Complete workflow per task**:

```bash
# For each task T{id} in tasks.md:

# 1. Create task branch
git checkout spec/{feature}
git pull origin spec/{feature}
git checkout -b task/{feature}/T{id}-{slug}

# 2. Implement (existing behavior)
# ... write tests, implement, verify ...

# 3. Commit
git add .
git commit -m "feat({area}): {description}

Implements T{id}
Refs #{issue-number}"

# 4. Push and create PR
git push -u origin task/{feature}/T{id}-{slug}

gh pr create \
  --base spec/{feature} \
  --title "[T{id}] {description}" \
  --body "Fixes #{issue-number}

{PR body}"

# 5. Wait for merge or continue to next task
# (configurable: auto-merge if checks pass, or wait for review)

# 6. After merge, cleanup
git checkout spec/{feature}
git pull origin spec/{feature}
git branch -d task/{feature}/T{id}-{slug}
```

### `/speckit.milestone` (NEW)

Completes a milestone:

```bash
# 1. Verify all milestone issues closed
open_issues=$(gh issue list --milestone "v{x.y.z}" --state open --json number | jq length)
if [ "$open_issues" -gt 0 ]; then
  echo "Error: $open_issues issues still open in milestone"
  exit 1
fi

# 2. Update version
npm version {x.y.z} --no-git-tag-version

# 3. Update CHANGELOG
# ... prepend release notes ...

# 4. Commit version bump
git add package.json package-lock.json CHANGELOG.md
git commit -m "chore: release v{x.y.z}"
git push

# 5. Create release PR to main
gh pr create --base main --head spec/{feature} \
  --title "Release v{x.y.z} - {theme}" \
  --body "{release notes}"

# 6. After merge: tag and release
git checkout main
git pull origin main
git tag -a v{x.y.z} -m "Release v{x.y.z}"
git push origin v{x.y.z}

gh release create v{x.y.z} \
  --title "v{x.y.z} - {theme}" \
  --notes-file CHANGELOG.md \
  --attach dist/*.vsix

# 7. Close milestone
gh api repos/{owner}/{repo}/milestones/{n} -X PATCH -f state="closed"
```

## Branch Protection Rules

Recommended GitHub settings:

### `main` branch:
- Require PR reviews (1+)
- Require status checks to pass
- Require branches to be up to date
- Disallow force pushes
- Disallow deletions

### `spec/*` branches:
- Require status checks to pass
- Allow force pushes (for rebasing task branches)
- Disallow deletions until milestone complete

## State Tracking

Track workflow state in `.specify/cache/workflow-state.json`:

```json
{
  "feature": "markdown-preview",
  "spec_branch": "spec/markdown-preview",
  "current_milestone": "v0.1.0",
  "tasks": {
    "T001": {
      "status": "merged",
      "branch": "task/markdown-preview/T001-test-scaffolding",
      "pr": 15,
      "issue": 1
    },
    "T002": {
      "status": "in_progress",
      "branch": "task/markdown-preview/T002-dependencies",
      "pr": null,
      "issue": 2
    }
  },
  "milestones": {
    "v0.1.0": {
      "status": "in_progress",
      "tasks_total": 52,
      "tasks_complete": 1,
      "release_pr": null
    }
  }
}
```

## Error Recovery

| Scenario | Recovery |
|----------|----------|
| PR merge conflict | Rebase task branch on spec branch |
| Task branch outdated | `git rebase spec/{feature}` |
| Wrong branch | Stash changes, checkout correct branch, apply |
| Failed milestone | Revert release commit, fix issues, retry |

## Example Full Workflow

```
# 1. Start new feature
/speckit.specify markdown-preview
# Creates: spec/markdown-preview branch, specs/.../spec.md

# 2. Create plan
/speckit.plan
# Adds: specs/.../plan.md, commits to spec branch

# 3. Generate tasks
/speckit.tasks
# Adds: specs/.../tasks.md, commits to spec branch

# 4. Create GitHub infrastructure
/speckit.issues
# Creates: milestones, labels, issues on GitHub

# 5. Implement tasks (repeat for each task)
/speckit.implement T001
# Creates: task branch, implements, creates PR to spec branch

# 6. Complete milestone
/speckit.milestone v0.1.0
# Creates: release PR to main, tags, GitHub release

# 7. Continue with next milestone
/speckit.implement T053  # First task of v0.2.0
# ...
```

## Mermaid Workflow Diagram

```mermaid
flowchart TD
    subgraph "Phase 1: Specification"
        A[main] -->|checkout -b| B[spec/feature]
        B -->|/speckit.specify| C[spec.md]
        C -->|/speckit.plan| D[plan.md]
        D -->|/speckit.tasks| E[tasks.md]
        E -->|/speckit.issues| F[GitHub Issues]
    end

    subgraph "Phase 2: Implementation"
        B -->|checkout -b| G[task/feature/T001]
        G -->|implement| H[Code + Tests]
        H -->|PR| B
        B -->|checkout -b| I[task/feature/T002]
        I -->|implement| J[Code + Tests]
        J -->|PR| B
    end

    subgraph "Phase 3: Release"
        B -->|/speckit.milestone| K[Release PR]
        K -->|merge| A
        A -->|tag| L[v0.1.0]
        L -->|gh release| M[GitHub Release]
    end

    style A fill:#90EE90
    style B fill:#4a90d9,color:#fff
    style L fill:#ffa500
```
