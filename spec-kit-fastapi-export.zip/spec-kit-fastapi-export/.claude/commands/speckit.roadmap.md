---
name: speckit.roadmap
description: |
  Generate comprehensive roadmap documentation (ROADMAP.md and ROADMAP-DIAGRAM.md)
  from tasks.md with Mermaid visualizations. TRIGGER: After /speckit.tasks completes
  OR when user mentions "roadmap", "milestone planning", "release schedule",
  "feature timeline", or "project overview". PREREQUISITE: specs/{feature}/tasks.md exists.
model: opus
---

# Roadmap Generation Skill

Transform implementation tasks into professional roadmap documentation using deep multi-artifact synthesis.

## Model Configuration

**Model**: Claude Opus 4.5
**Rationale**: Roadmap generation requires:
- Cross-artifact reasoning (spec + plan + tasks)
- Strategic synthesis and pattern recognition
- Complex Mermaid diagram generation
- Long-horizon context maintenance

**Extended Thinking**: Use "think hard" before generating output.

## Execution Protocol

**MANDATORY**: Before generating ANY output, think hard about:

1. **Cross-Artifact Correlation**
   - How do user stories in spec.md map to phases in tasks.md?
   - What architectural decisions from plan.md affect milestone grouping?
   - Are there dependency chains that affect version boundaries?

2. **Version Strategy Analysis**
   - Does the MVP scope deliver standalone user value?
   - Are there natural breaking points between user stories?
   - Do quality gates (testing, polish) warrant a separate version?

3. **Visualization Value Assessment**
   - Which diagrams provide unique insights vs redundant information?
   - Is the project scope appropriate for all diagram types?
   - Can complex relationships be simplified without losing meaning?

## Prerequisites

Verify before proceeding:
- `specs/{feature}/tasks.md` exists with phase-organized tasks
- `specs/{feature}/plan.md` exists with technical context
- `specs/{feature}/spec.md` exists with user stories and requirements

## Inputs

Load these files COMPLETELY before synthesis:

1. **tasks.md**: Phase structure, task counts, MVP scope, parallel markers
2. **plan.md**: Technical architecture, project structure, dependencies
3. **spec.md**: User stories (priorities P1-P6), acceptance criteria, NFRs
4. **constitution.md** (optional): Design principles, quality gates

## Outputs

### 1. ROADMAP.md

Executive-level roadmap with:

```markdown
# {Project Name} - Roadmap

> {Brief value proposition} (rolling, no fixed dates)

---

## Executive Summary

**Current State:** v0.0.0 - Pre-release development

**Core Value Proposition:**
1. {Primary user benefit}
2. {Secondary user benefit}
3. {Tertiary user benefit}

**Design Principles:** {Extract from constitution}

---

## Version Milestones

### v0.1.0 - MVP Core

**Theme:** {One-line value statement}
**Phases Included:** Setup, Foundational, US1, US2
**Task Count:** {X} tasks

#### Features

| Priority | Feature | User Story | Status |
|----------|---------|------------|--------|
| P0 | **{Feature}** | US1 | Planned |

#### Quality Gates

- All tests passing (80%+ coverage)
- No ESLint warnings
- JSDoc on public APIs

### v0.2.0 - {Theme}
{Continue pattern...}

---

## Feature Comparison Matrix

| Feature | v0.1 | v0.2 | v0.3 | v1.0 |
|---------|:----:|:----:|:----:|:----:|
| {Feature} | :white_check_mark: | | | :white_check_mark: |

---

## Success Metrics

| Metric | MVP Target | v1.0 Target | Source |
|--------|------------|-------------|--------|
| {Metric} | {Value} | {Value} | SC-XXX |

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|:-----------:|:------:|------------|
| {Risk} | Medium | High | {Strategy} |

---

## Task Summary

| Phase | Tasks | Parallel | Description |
|-------|:-----:|:--------:|-------------|
| Setup | 11 | 7 | Test and build infrastructure |

**Total**: {X} tasks | **MVP**: {Y} tasks

---

*Roadmap v1.0 (rolling) - No time estimates per project constitution*
```

### 2. ROADMAP-DIAGRAM.md

Select diagrams that provide UNIQUE value:

**Always Include:**
1. Timeline Evolution - Shows version progression
2. Feature Dependency Graph - Critical path visualization
3. Task Distribution Pie - Phase effort visualization

**Include If Valuable:**
4. Priority/Effort Quadrant - For complex feature sets
5. User Journey - For user-facing features
6. Architecture Evolution - For significant structural changes

**Mermaid Styling:**
```mermaid
%%{init: {'theme': 'base', 'themeVariables': {
  'primaryColor': '#4A90A4',
  'primaryTextColor': '#fff',
  'secondaryColor': '#81C784',
  'tertiaryColor': '#FFB74D'
}}}%%
```

**Color Semantics:**
- MVP/Core: `#81C784` (green)
- Enhancement: `#4A90A4` (blue)
- Polish: `#FFB74D` (orange)
- Critical Path: `#ff6b6b` (red)

## Version Mapping Rules

| Phase Pattern | Version | Theme Pattern |
|---------------|---------|---------------|
| Setup + Foundational + US1 + US2 | v0.1.0 | MVP Core |
| US3 (next major feature) | v0.2.0 | {US3 title} |
| US4, US5 | v0.3.0 | Access & UX |
| US6 | v0.4.0 | Configuration |
| Testing + Polish | v1.0.0 | Stable Release |

## Self-Verification Checklist

Before finalizing, verify:
- [ ] All user stories from spec.md represented in version milestones
- [ ] Task counts match tasks.md summary exactly
- [ ] MVP scope aligns with plan.md definition
- [ ] Success metrics trace to spec.md SC-XXX references
- [ ] Mermaid diagrams render without syntax errors
- [ ] No time estimates included (per constitution)
- [ ] Risk assessment covers technical risks from plan.md

## Git Operations

```bash
git add ROADMAP.md ROADMAP-DIAGRAM.md
git commit -m "docs: generate project roadmap with visualizations

Synthesizes spec.md, plan.md, and tasks.md into:
- ROADMAP.md: Executive overview with {N} version milestones
- ROADMAP-DIAGRAM.md: {M} Mermaid visualizations"
```
