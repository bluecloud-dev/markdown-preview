---
name: speckit.milestone
description: |
  Complete a milestone by creating release PR to main, tagging, and publishing GitHub Release.
  TRIGGER: When user says "complete milestone", "release", "finish v0.x.x".
  PREREQUISITE: All milestone issues closed, on spec/{feature} branch.
model: sonnet
---

# Milestone Completion Skill

Finalize a milestone with release PR, version tag, and GitHub release.

## Model Configuration

**Model**: Claude Sonnet 4.5
**Rationale**: Milestone completion is execution-focused:
- Sequential Git/GitHub operations
- Template application for release notes
- Clear validation checkpoints
- Explicit step-by-step workflow

## Execution Protocol

**EXPLICIT INSTRUCTIONS** - Execute each step precisely:

### Step 1: Pre-Flight Verification

```bash
version="$1"  # e.g., 0.1.0

# 1. Verify on spec branch
current_branch=$(git branch --show-current)
if [[ ! "$current_branch" =~ ^spec/ ]]; then
  echo "❌ Must be on spec branch"
  exit 1
fi
feature_name=$(echo "$current_branch" | sed 's|spec/||')

# 2. Verify clean working directory
if [ -n "$(git status --porcelain)" ]; then
  echo "❌ Uncommitted changes"
  exit 1
fi

# 3. Get repo info
repo_info=$(gh repo view --json owner,name)
owner=$(echo "$repo_info" | jq -r '.owner.login')
repo=$(echo "$repo_info" | jq -r '.name')

# 4. Find milestone
milestone_number=$(gh api "repos/$owner/$repo/milestones" \
  --jq ".[] | select(.title == \"v$version\") | .number")

if [ -z "$milestone_number" ]; then
  echo "❌ Milestone v$version not found"
  exit 1
fi

# 5. Check all issues closed
open_count=$(gh issue list --milestone "v$version" --state open --json number | jq length)
if [ "$open_count" -gt 0 ]; then
  echo "❌ $open_count issues still open"
  gh issue list --milestone "v$version" --state open --json number,title \
    --jq '.[] | "  #\(.number): \(.title)"'
  exit 1
fi

echo "✅ Pre-flight passed"
echo "   Milestone: v$version (#$milestone_number)"
echo "   Branch: $current_branch"
```

### Step 1.5: Mandatory Test Gate (BLOCKING)

**⚠️ CRITICAL**: Milestone CANNOT be completed if test gate fails.

```bash
echo "🧪 Running mandatory test gate..."

# Run full test suite
echo "  → Running tests..."
if ! npm test; then
  echo "❌ GATE FAILED: Tests are failing"
  echo "   Fix failing tests before completing milestone"
  exit 1
fi

# Check coverage
echo "  → Checking coverage..."
if ! npm run coverage 2>/dev/null; then
  echo "⚠️ Coverage check not available - skipping"
else
  # Parse coverage from report (adjust based on project)
  coverage=$(npm run coverage 2>&1 | grep -oP 'Statements\s*:\s*\K[\d.]+' | head -1)
  if [ -n "$coverage" ] && [ "$(echo "$coverage < 80" | bc)" -eq 1 ]; then
    echo "❌ GATE FAILED: Coverage ${coverage}% < 80% threshold"
    exit 1
  fi
  echo "   Coverage: ${coverage:-N/A}%"
fi

# Run linter
echo "  → Running linter..."
if ! npm run lint; then
  echo "❌ GATE FAILED: Lint errors present"
  echo "   Fix lint errors before completing milestone"
  exit 1
fi

echo "✅ Test gate passed - milestone can proceed"
```

### Step 2: Update Version

```bash
# Update package.json
npm version "$version" --no-git-tag-version

# Verify update
new_version=$(jq -r '.version' package.json)
if [ "$new_version" != "$version" ]; then
  echo "❌ Version update failed"
  exit 1
fi

echo "✅ Version updated to $version"
```

### Step 3: Update CHANGELOG.md

Generate changelog entry:

```bash
# Get milestone info
milestone_info=$(gh api "repos/$owner/$repo/milestones/$milestone_number")
milestone_desc=$(echo "$milestone_info" | jq -r '.description // "Release"')

# Get closed issues grouped by type
closed_issues=$(gh issue list --milestone "v$version" --state closed --json number,title,labels)

# Build changelog
cat > /tmp/changelog_entry.md <<EOF
## [$version] - $(date +%Y-%m-%d)

### Added

$(echo "$closed_issues" | jq -r '.[] | select(.labels[].name == "type:feat") | "- \(.title) (#\(.number))"' | head -20)

### Changed

$(echo "$closed_issues" | jq -r '.[] | select(.labels[].name == "type:refactor") | "- \(.title) (#\(.number))"' | head -10)

### Fixed

$(echo "$closed_issues" | jq -r '.[] | select(.labels[].name == "type:fix") | "- \(.title) (#\(.number))"' | head -10)

### Documentation

$(echo "$closed_issues" | jq -r '.[] | select(.labels[].name == "type:docs") | "- \(.title) (#\(.number))"' | head -10)

EOF

# Prepend to CHANGELOG.md
if [ -f CHANGELOG.md ]; then
  # Insert after header
  head -n 6 CHANGELOG.md > /tmp/changelog_new.md
  cat /tmp/changelog_entry.md >> /tmp/changelog_new.md
  tail -n +7 CHANGELOG.md >> /tmp/changelog_new.md
  mv /tmp/changelog_new.md CHANGELOG.md
else
  # Create new
  cat > CHANGELOG.md <<EOF
# Changelog

All notable changes documented here. Format based on [Keep a Changelog](https://keepachangelog.com/).

$(cat /tmp/changelog_entry.md)
EOF
fi

echo "✅ CHANGELOG.md updated"
```

### Step 4: Commit Version Bump

```bash
git add package.json package-lock.json CHANGELOG.md
git commit -m "chore: release v$version

- Bump version to $version
- Update CHANGELOG.md

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude Sonnet 4.5 <noreply@anthropic.com>"

git push origin "$current_branch"

echo "✅ Version commit pushed"
```

### Step 5: Create Release PR

```bash
# Get issue list for PR body
closed_issues=$(gh issue list --milestone "v$version" --state closed --json number,title)
issue_list=$(echo "$closed_issues" | jq -r '.[] | "- Closes #\(.number)"')

pr_body=$(cat <<EOF
## Release v$version - $milestone_desc

### Summary

This release completes milestone **v$version**.

$milestone_desc

### Features Included

$(echo "$closed_issues" | jq -r '.[] | select(.title | contains("[T")) | "- #\(.number) \(.title)"' | head -30)

### Issues Closed

$issue_list

### Quality Checklist

- [ ] All tests passing
- [ ] Coverage ≥80%
- [ ] No ESLint warnings
- [ ] CHANGELOG.md updated
- [ ] package.json version correct

### Post-Merge

After merge:
1. Tag: \`v$version\`
2. GitHub Release published
3. Milestone closed

---
**Milestone**: https://github.com/$owner/$repo/milestone/$milestone_number
EOF
)

pr_url=$(gh pr create \
  --base main \
  --head "$current_branch" \
  --title "Release v$version - $milestone_desc" \
  --body "$pr_body")

echo "✅ Release PR: $pr_url"
```

### Step 6: Post-Merge Actions

**Execute AFTER PR is merged:**

```bash
# Switch to main
git checkout main
git pull origin main

# Create annotated tag
git tag -a "v$version" -m "Release v$version

$milestone_desc

See CHANGELOG.md for details."

# Push tag
git push origin "v$version"

echo "✅ Tag v$version pushed"
```

### Step 7: Create GitHub Release

```bash
# Build extension if applicable
if [ -f "package.json" ] && grep -q "vsce" package.json; then
  npm run package
  vsix_file=$(ls -t *.vsix 2>/dev/null | head -1)
fi

# Extract release notes
release_notes=$(sed -n "/## \[$version\]/,/## \[/p" CHANGELOG.md | head -n -1)

# Create release
gh release create "v$version" \
  --title "v$version - $milestone_desc" \
  --notes "$release_notes" \
  ${vsix_file:+--attach "$vsix_file"}

echo "✅ GitHub Release published"
```

### Step 8: Close Milestone

```bash
gh api "repos/$owner/$repo/milestones/$milestone_number" \
  -X PATCH \
  -f state="closed"

echo "✅ Milestone v$version closed"
```

## Validation Checkpoints

| Step | Validation |
|------|------------|
| 1 | On spec branch, clean, all issues closed |
| **1.5** | **🧪 TEST GATE: All tests pass, coverage ≥80%, no lint errors** |
| 2 | package.json version matches |
| 4 | Commit pushed successfully |
| 5 | PR created |
| 6 | Tag pushed (after merge) |
| 7 | Release created |
| 8 | Milestone closed |

**If any step fails: STOP and report error with recovery instructions.**

**⚠️ CRITICAL**: Step 1.5 (Test Gate) is MANDATORY. Milestone CANNOT proceed if:
- Any test fails
- Coverage is below threshold (80% default)
- Lint errors are present

## Error Handling

| Error | Recovery |
|-------|----------|
| **Test gate failed** | **Fix failing tests/coverage/lint before proceeding - DO NOT SKIP** |
| Open issues remain | List issues, wait for closure |
| Version exists | Increment patch version |
| PR conflict | Rebase on main |
| Tag exists | Delete and recreate (if necessary) |
| Release failed | Retry with `gh release create` |

## Output

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Milestone v0.1.0 Complete
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Version: 0.1.0
Theme: MVP Core - Preview by Default

PR: https://github.com/user/repo/pull/64
Tag: v0.1.0
Release: https://github.com/user/repo/releases/tag/v0.1.0

Issues Closed: 63
Milestone: Closed

Next Steps:
1. Announce release
2. Continue with v0.2.0 tasks
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

## GitHub Actions Automation

Optional: Automate post-merge actions:

```yaml
# .github/workflows/release.yml
name: Release
on:
  pull_request:
    types: [closed]
    branches: [main]

jobs:
  release:
    if: |
      github.event.pull_request.merged == true &&
      startsWith(github.event.pull_request.title, 'Release v')
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

      - name: Extract version
        id: version
        run: |
          version=$(echo "${{ github.event.pull_request.title }}" | grep -oP 'v\d+\.\d+\.\d+')
          echo "version=$version" >> $GITHUB_OUTPUT

      - name: Create tag
        run: |
          git tag -a ${{ steps.version.outputs.version }} -m "Release ${{ steps.version.outputs.version }}"
          git push origin ${{ steps.version.outputs.version }}

      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Build and release
        run: |
          npm ci
          npm run package

      - uses: softprops/action-gh-release@v1
        with:
          tag_name: ${{ steps.version.outputs.version }}
          files: '*.vsix'
          generate_release_notes: true
```
