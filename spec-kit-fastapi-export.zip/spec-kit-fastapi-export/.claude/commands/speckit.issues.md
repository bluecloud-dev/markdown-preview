---
name: speckit.issues
description: |
  Create GitHub issues from tasks.md with milestones, labels, and project organization.
  TRIGGER: After /speckit.tasks OR when user mentions "create issues", "github setup",
  "project infrastructure". PREREQUISITE: specs/{feature}/tasks.md exists, gh CLI authenticated.
model: sonnet
---

# GitHub Issues Generation Skill

Transform implementation tasks into a well-organized GitHub project with milestones, labels, and issues.

## Model Configuration

**Model**: Claude Sonnet 4.5
**Rationale**: Issue creation is execution-focused:
- Repetitive API calls with template application
- Clear input/output transformation
- Speed matters for bulk operations
- Explicit validation checkpoints

## Execution Protocol

**EXPLICIT INSTRUCTIONS** - Follow each step precisely:

### Step 1: Pre-Flight Verification

```bash
# Check gh authentication
gh auth status
if [ $? -ne 0 ]; then
  echo "❌ Not authenticated. Run: gh auth login"
  exit 1
fi

# Get repository info
repo_info=$(gh repo view --json owner,name)
owner=$(echo "$repo_info" | jq -r '.owner.login')
repo=$(echo "$repo_info" | jq -r '.name')
echo "✅ Repository: $owner/$repo"

# Check existing resources
existing_milestones=$(gh api "repos/$owner/$repo/milestones" --jq '.[].title')
existing_labels=$(gh api "repos/$owner/$repo/labels" --jq '.[].name' | grep -E '^(type:|area:|priority:|status:)' | wc -l)

if [ -n "$existing_milestones" ]; then
  echo "⚠️ Found existing milestones: $existing_milestones"
  echo "Continue? (y/n)"
fi
```

### Step 2: Create Labels (Idempotent)

Execute these commands. Skip if label exists:

```bash
create_label() {
  gh label create "$1" --color "$2" --description "$3" 2>/dev/null || \
  gh label edit "$1" --color "$2" --description "$3" 2>/dev/null || true
}

# Type labels
create_label "type:feat" "1D76DB" "New feature or enhancement"
create_label "type:fix" "D73A4A" "Bug fix"
create_label "type:docs" "0075CA" "Documentation only"
create_label "type:test" "BFD4F2" "Tests and test infrastructure"
create_label "type:refactor" "FEF2C0" "Code refactoring"
create_label "type:chore" "EDEDED" "Build, tooling, dependencies"
create_label "type:perf" "FBCA04" "Performance improvement"
create_label "type:a11y" "C2E0C6" "Accessibility"

# Priority labels
create_label "priority:P0" "B60205" "Critical - Must have"
create_label "priority:P1" "D93F0B" "High - Should have"
create_label "priority:P2" "FBCA04" "Medium - Could have"
create_label "priority:P3" "C2E0C6" "Low - Nice to have"

# Status labels
create_label "status:blocked" "B60205" "Blocked by dependency"
create_label "status:in-progress" "0E8A16" "Work in progress"
create_label "status:needs-review" "FBCA04" "Ready for review"

# Special labels
create_label "epic" "3E4B9E" "Parent tracking issue"
create_label "mvp" "0E8A16" "Part of MVP milestone"
create_label "good first issue" "7057FF" "Good for newcomers"

echo "✅ Labels created/updated"
```

### Step 3: Create Milestones

```bash
create_milestone() {
  gh api "repos/$owner/$repo/milestones" \
    -f title="$1" \
    -f description="$2" \
    -f state="open" 2>/dev/null || echo "Milestone $1 exists"
}

# Create version milestones (no due dates per constitution)
create_milestone "v0.1.0" "MVP Core - Preview by Default with Edit Mode"
create_milestone "v0.2.0" "Formatting Toolbar"
create_milestone "v0.3.0" "Access & Shortcuts"
create_milestone "v0.4.0" "Configuration"
create_milestone "v1.0.0" "Stable & Polished"

echo "✅ Milestones created"
```

### Step 4: Parse Tasks from tasks.md

For each task line matching pattern `- [ ] T### ...`:

| Field | Extraction |
|-------|------------|
| Task ID | `T###` after checkbox |
| Description | Text after task ID |
| Parallel | `[P]` marker present |
| User Story | `[US#]` marker |
| Phase | Section header |

### Step 5: Create Issues

**Issue Template:**
```markdown
## Task

{Task description from tasks.md}

## Context

- **Phase**: {Phase name}
- **User Story**: {US# if applicable, else "Infrastructure"}
- **Parallel**: {Yes/No based on [P] marker}

## Acceptance Criteria

{Derive from task or reference spec}

## Dependencies

{List blocking tasks as issue links if known}

---

**Task ID**: {T###}
**Spec**: [spec.md](specs/{feature}/spec.md)
**Tasks**: [tasks.md](specs/{feature}/tasks.md)
```

**Label Assignment Rules:**

| Task Pattern | Labels |
|--------------|--------|
| Phase 1 (Setup) | `type:chore`, `priority:P0`, `mvp` |
| Phase 2 (Foundational) | `type:feat`, `priority:P0`, `mvp` |
| "Create test..." | `type:test` |
| "Add...config" | `type:feat`, `area:config` |
| "Implement...Service" | `type:feat`, `area:services` |
| "Register...command" | `type:feat`, `area:commands` |
| "Add JSDoc..." | `type:docs` |
| MVP phases (1-4) | Add `mvp` label |

**Priority Mapping:**

| Phase/Story | Priority |
|-------------|----------|
| Setup, Foundational, US1, US2 | `priority:P0` |
| US3 | `priority:P1` |
| US4, US5 | `priority:P2` |
| US6 | `priority:P2` |
| Testing, Polish | `priority:P1` |

**Milestone Mapping:**

| Phase | Milestone |
|-------|-----------|
| 1-4 (Setup through US2) | v0.1.0 |
| 5 (US3) | v0.2.0 |
| 6-7 (US4, US5) | v0.3.0 |
| 8 (US6) | v0.4.0 |
| 9-10 (Testing, Polish) | v1.0.0 |

**Issue Creation Command:**
```bash
gh issue create \
  --title "[T001] Create test scaffolding" \
  --body "$(cat issue-body.md)" \
  --label "type:chore,priority:P0,mvp" \
  --milestone "v0.1.0"
```

### Step 6: Validation Checkpoint

After each batch of 10 issues:
```bash
# Verify issues created
issue_count=$(gh issue list --milestone "v0.1.0" --json number | jq length)
echo "Created $issue_count issues for v0.1.0"

# Check for errors
if [ $? -ne 0 ]; then
  echo "❌ Error creating issues. Check rate limits."
  exit 1
fi
```

### Step 7: Create Epic Issues

For each user story, create an epic:

```markdown
## Epic: {User Story Title}

**Priority**: P{n}
**Milestone**: v{x.y.z}

### User Story

{Story from spec.md}

### Acceptance Criteria

{From spec.md}

### Tasks

- [ ] #{issue} [T###] {task}
- [ ] #{issue} [T###] {task}

### Progress

0/{count} tasks complete
```

```bash
gh issue create \
  --title "Epic: Preview Markdown by Default (US1)" \
  --body "$(cat epic-body.md)" \
  --label "epic,priority:P0,mvp" \
  --milestone "v0.1.0"
```

## Error Handling

| Error | Action |
|-------|--------|
| Rate limit | Wait 60s, retry |
| Label exists | Skip (idempotent) |
| Milestone exists | Skip (idempotent) |
| Issue creation fails | Log task ID, continue |
| Network error | Retry 3x with backoff |

## Checkpoint Recovery

Save progress to `.specify/cache/issues-checkpoint.json`:

```json
{
  "feature": "markdown-preview",
  "timestamp": "2025-12-26T10:00:00Z",
  "labels_created": true,
  "milestones_created": true,
  "issues_created": ["T001", "T002"],
  "issues_pending": ["T003", "T004"],
  "errors": []
}
```

## Output Summary

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GitHub Project Setup Complete
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Labels: 20 created
Milestones: 5 created
  - v0.1.0: 63 issues (MVP)
  - v0.2.0: 19 issues
  - v0.3.0: 19 issues
  - v0.4.0: 13 issues
  - v1.0.0: 25 issues

Issues: 139 total
  - Epics: 6
  - Tasks: 133

View: gh issue list --milestone "v0.1.0"
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
